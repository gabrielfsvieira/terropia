window.WORLD_EDITOR_RUNTIME_LIBRARY={
  "generatedAt": "2026-08-17T13:29:45.276Z",
  "sourceFiles": [
    "data/content.js",
    "data/economy.js",
    "data/equipment.js",
    "data/fish.js",
    "data/gathering-requirements.js",
    "data/locations.js",
    "data/map-codes.js",
    "data/mastery.js",
    "data/overworld-expansion-plan-v00146.js",
    "data/perks.js",
    "data/production-chains.js",
    "data/profession-quests.js",
    "data/professional-contracts.js",
    "data/progression-balance.js",
    "data/quest-skill-checks.js",
    "data/recipes.js",
    "data/resources.js",
    "data/skill-endgame.js",
    "data/skills.js",
    "data/tiers.js",
    "data/unlocks.js",
    "data/world-map-v00156.js",
    "data/world-map-v00157.js",
    "data/world-map-v00163.js",
    "data/world-projects.js",
    "data/world.js",
    "js/ambient-animation.js",
    "js/battle-v47.js",
    "js/battle-visuals.js",
    "js/battle.js",
    "js/building-visuals.js",
    "js/camera-polish.js",
    "js/core.js",
    "js/crafting.js",
    "js/entities.js",
    "js/event-bus.js",
    "js/floating-text.js",
    "js/gathering-vfx.js",
    "js/gathering.js",
    "js/input.js",
    "js/interaction-visuals.js",
    "js/inventory.js",
    "js/item-icons.js",
    "js/lighting.js",
    "js/main.js",
    "js/pwa.js",
    "js/quest.js",
    "js/region-identity.js",
    "js/region-props.js",
    "js/render-cache.js",
    "js/renderer-layers.js",
    "js/requirements.js",
    "js/reward-presentation.js",
    "js/shadow-system.js",
    "js/sprites.js",
    "js/state-save.js",
    "js/terrain-autotile.js",
    "js/terrain-visuals.js",
    "js/ui.js",
    "js/vegetation-visuals.js",
    "js/water-visuals.js",
    "js/world-decor.js",
    "js/world.js"
  ],
  "sourceHash": "a572ec2808da05bfa708",
  "screens": [
    {
      "code": "AT-005",
      "x": 1,
      "y": 18,
      "area": "village",
      "name": "AT-005",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-006",
      "x": 0,
      "y": 18,
      "area": "village2",
      "name": "AT-006",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-007",
      "x": 2,
      "y": 18,
      "area": "entrance",
      "name": "AT-007",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-011",
      "x": 2,
      "y": 17,
      "area": "witchyard",
      "name": "AT-011",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-012",
      "x": 3,
      "y": 17,
      "area": "darkforest",
      "name": "AT-012",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-014",
      "x": 2,
      "y": 19,
      "area": "mushroomforest",
      "name": "AT-014",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-015",
      "x": 0,
      "y": 17,
      "area": "atenaria015",
      "name": "AT-015",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-016",
      "x": 1,
      "y": 17,
      "area": "atenaria016",
      "name": "AT-016",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-017",
      "x": 4,
      "y": 17,
      "area": "atenaria017",
      "name": "AT-017",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-018",
      "x": 3,
      "y": 18,
      "area": "atenaria018",
      "name": "AT-018",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-019",
      "x": 4,
      "y": 18,
      "area": "atenaria019",
      "name": "AT-019",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-020",
      "x": 3,
      "y": 19,
      "area": "atenaria020",
      "name": "AT-020",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-021",
      "x": 4,
      "y": 19,
      "area": "atenaria021",
      "name": "AT-021",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-022",
      "x": 1,
      "y": 19,
      "area": "atenaria022",
      "name": "AT-022",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-023",
      "x": 0,
      "y": 19,
      "area": "atenaria023",
      "name": "AT-023",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-024",
      "x": 5,
      "y": 17,
      "area": "altaria024",
      "name": "AT-024",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-025",
      "x": 6,
      "y": 17,
      "area": "altaria025",
      "name": "AT-025",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-026",
      "x": 7,
      "y": 17,
      "area": "altaria026",
      "name": "AT-026",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-027",
      "x": 8,
      "y": 17,
      "area": "altaria027",
      "name": "AT-027",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-028",
      "x": 6,
      "y": 18,
      "area": "altaria028",
      "name": "AT-028",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-029",
      "x": 7,
      "y": 18,
      "area": "altaria029",
      "name": "AT-029",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-030",
      "x": 8,
      "y": 18,
      "area": "altaria030",
      "name": "AT-030",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-031",
      "x": 9,
      "y": 18,
      "area": "altaria031",
      "name": "AT-031",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-032",
      "x": 5,
      "y": 19,
      "area": "altaria032",
      "name": "AT-032",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-033",
      "x": 6,
      "y": 19,
      "area": "altaria033",
      "name": "AT-033",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-034",
      "x": 7,
      "y": 19,
      "area": "altaria034",
      "name": "AT-034",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-035",
      "x": 8,
      "y": 19,
      "area": "altaria035",
      "name": "AT-035",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-036",
      "x": 9,
      "y": 19,
      "area": "altaria036",
      "name": "AT-036",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-037",
      "x": 6,
      "y": 20,
      "area": "altaria037",
      "name": "AT-037",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-038",
      "x": 8,
      "y": 20,
      "area": "altaria038",
      "name": "AT-038",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-039",
      "x": 0,
      "y": 9,
      "area": "mornaqua039",
      "name": "AT-039",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-040",
      "x": 1,
      "y": 9,
      "area": "mornaqua040",
      "name": "AT-040",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-041",
      "x": 2,
      "y": 9,
      "area": "mornaqua041",
      "name": "AT-041",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-042",
      "x": 3,
      "y": 9,
      "area": "mornaqua042",
      "name": "AT-042",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-043",
      "x": 1,
      "y": 10,
      "area": "mornaqua043",
      "name": "AT-043",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-044",
      "x": 2,
      "y": 10,
      "area": "mornaqua044",
      "name": "AT-044",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-045",
      "x": 3,
      "y": 10,
      "area": "mornaqua045",
      "name": "AT-045",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-046",
      "x": 4,
      "y": 10,
      "area": "mornaqua046",
      "name": "AT-046",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-047",
      "x": 0,
      "y": 11,
      "area": "mornaqua047",
      "name": "AT-047",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-048",
      "x": 1,
      "y": 11,
      "area": "mornaqua048",
      "name": "AT-048",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-049",
      "x": 2,
      "y": 11,
      "area": "mornaqua049",
      "name": "AT-049",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-050",
      "x": 3,
      "y": 11,
      "area": "mornaqua050",
      "name": "AT-050",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-051",
      "x": 4,
      "y": 11,
      "area": "mornaqua051",
      "name": "AT-051",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-052",
      "x": 1,
      "y": 12,
      "area": "mornaqua052",
      "name": "AT-052",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-053",
      "x": 3,
      "y": 12,
      "area": "mornaqua053",
      "name": "AT-053",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-054",
      "x": 5,
      "y": 9,
      "area": "calindra054",
      "name": "AT-054",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-055",
      "x": 6,
      "y": 9,
      "area": "calindra055",
      "name": "AT-055",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-056",
      "x": 7,
      "y": 9,
      "area": "calindra056",
      "name": "AT-056",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-057",
      "x": 8,
      "y": 9,
      "area": "calindra057",
      "name": "AT-057",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-058",
      "x": 6,
      "y": 10,
      "area": "calindra058",
      "name": "AT-058",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-059",
      "x": 7,
      "y": 10,
      "area": "calindra059",
      "name": "AT-059",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-060",
      "x": 8,
      "y": 10,
      "area": "calindra060",
      "name": "AT-060",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-061",
      "x": 9,
      "y": 10,
      "area": "calindra061",
      "name": "AT-061",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-062",
      "x": 5,
      "y": 11,
      "area": "calindra062",
      "name": "AT-062",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-063",
      "x": 6,
      "y": 11,
      "area": "calindra063",
      "name": "AT-063",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-064",
      "x": 7,
      "y": 11,
      "area": "calindra064",
      "name": "AT-064",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-065",
      "x": 8,
      "y": 11,
      "area": "calindra065",
      "name": "AT-065",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-066",
      "x": 9,
      "y": 11,
      "area": "calindra066",
      "name": "AT-066",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-067",
      "x": 6,
      "y": 12,
      "area": "calindra067",
      "name": "AT-067",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-068",
      "x": 8,
      "y": 12,
      "area": "calindra068",
      "name": "AT-068",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-069",
      "x": 9,
      "y": 6,
      "area": "solacia069",
      "name": "AT-069",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-070",
      "x": 10,
      "y": 6,
      "area": "solacia070",
      "name": "AT-070",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-071",
      "x": 11,
      "y": 6,
      "area": "solacia071",
      "name": "AT-071",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-072",
      "x": 12,
      "y": 6,
      "area": "solacia072",
      "name": "AT-072",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-073",
      "x": 10,
      "y": 7,
      "area": "solacia073",
      "name": "AT-073",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-074",
      "x": 11,
      "y": 7,
      "area": "solacia074",
      "name": "AT-074",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-075",
      "x": 12,
      "y": 7,
      "area": "solacia075",
      "name": "AT-075",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-076",
      "x": 13,
      "y": 7,
      "area": "solacia076",
      "name": "AT-076",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-077",
      "x": 9,
      "y": 8,
      "area": "solacia077",
      "name": "AT-077",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-078",
      "x": 10,
      "y": 8,
      "area": "solacia078",
      "name": "AT-078",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-079",
      "x": 11,
      "y": 8,
      "area": "solacia079",
      "name": "AT-079",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-080",
      "x": 12,
      "y": 8,
      "area": "solacia080",
      "name": "AT-080",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-081",
      "x": 13,
      "y": 8,
      "area": "solacia081",
      "name": "AT-081",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-082",
      "x": 10,
      "y": 9,
      "area": "solacia082",
      "name": "AT-082",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-083",
      "x": 12,
      "y": 9,
      "area": "solacia083",
      "name": "AT-083",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-084",
      "x": 12,
      "y": 3,
      "area": "blaziria084",
      "name": "AT-084",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-085",
      "x": 13,
      "y": 3,
      "area": "blaziria085",
      "name": "AT-085",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-086",
      "x": 14,
      "y": 3,
      "area": "blaziria086",
      "name": "AT-086",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-087",
      "x": 15,
      "y": 3,
      "area": "blaziria087",
      "name": "AT-087",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-088",
      "x": 13,
      "y": 4,
      "area": "blaziria088",
      "name": "AT-088",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-089",
      "x": 14,
      "y": 4,
      "area": "blaziria089",
      "name": "AT-089",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-090",
      "x": 15,
      "y": 4,
      "area": "blaziria090",
      "name": "AT-090",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-091",
      "x": 16,
      "y": 4,
      "area": "blaziria091",
      "name": "AT-091",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-092",
      "x": 12,
      "y": 5,
      "area": "blaziria092",
      "name": "AT-092",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-093",
      "x": 13,
      "y": 5,
      "area": "blaziria093",
      "name": "AT-093",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-094",
      "x": 14,
      "y": 5,
      "area": "blaziria094",
      "name": "AT-094",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-095",
      "x": 15,
      "y": 5,
      "area": "blaziria095",
      "name": "AT-095",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-096",
      "x": 16,
      "y": 5,
      "area": "blaziria096",
      "name": "AT-096",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-097",
      "x": 13,
      "y": 6,
      "area": "blaziria097",
      "name": "AT-097",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-098",
      "x": 15,
      "y": 6,
      "area": "blaziria098",
      "name": "AT-098",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-099",
      "x": 15,
      "y": 0,
      "area": "necrovicia099",
      "name": "AT-099",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-100",
      "x": 16,
      "y": 0,
      "area": "necrovicia100",
      "name": "AT-100",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-101",
      "x": 17,
      "y": 0,
      "area": "necrovicia101",
      "name": "AT-101",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-102",
      "x": 18,
      "y": 0,
      "area": "necrovicia102",
      "name": "AT-102",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-103",
      "x": 16,
      "y": 1,
      "area": "necrovicia103",
      "name": "AT-103",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-104",
      "x": 17,
      "y": 1,
      "area": "necrovicia104",
      "name": "AT-104",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-105",
      "x": 18,
      "y": 1,
      "area": "necrovicia105",
      "name": "AT-105",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-106",
      "x": 19,
      "y": 1,
      "area": "necrovicia106",
      "name": "AT-106",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-107",
      "x": 15,
      "y": 2,
      "area": "necrovicia107",
      "name": "AT-107",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-108",
      "x": 16,
      "y": 2,
      "area": "necrovicia108",
      "name": "AT-108",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-109",
      "x": 17,
      "y": 2,
      "area": "necrovicia109",
      "name": "AT-109",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-110",
      "x": 18,
      "y": 2,
      "area": "necrovicia110",
      "name": "AT-110",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-111",
      "x": 19,
      "y": 2,
      "area": "necrovicia111",
      "name": "AT-111",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-112",
      "x": 16,
      "y": 3,
      "area": "necrovicia112",
      "name": "AT-112",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-113",
      "x": 18,
      "y": 3,
      "area": "necrovicia113",
      "name": "AT-113",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-114",
      "x": 5,
      "y": 13,
      "area": "invernia114",
      "name": "AT-114",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-115",
      "x": 6,
      "y": 13,
      "area": "invernia115",
      "name": "AT-115",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-116",
      "x": 7,
      "y": 13,
      "area": "invernia116",
      "name": "AT-116",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-117",
      "x": 8,
      "y": 13,
      "area": "invernia117",
      "name": "AT-117",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-118",
      "x": 6,
      "y": 14,
      "area": "invernia118",
      "name": "AT-118",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-119",
      "x": 7,
      "y": 14,
      "area": "invernia119",
      "name": "AT-119",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-120",
      "x": 8,
      "y": 14,
      "area": "invernia120",
      "name": "AT-120",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-121",
      "x": 9,
      "y": 14,
      "area": "invernia121",
      "name": "AT-121",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-122",
      "x": 5,
      "y": 15,
      "area": "invernia122",
      "name": "AT-122",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-123",
      "x": 6,
      "y": 15,
      "area": "invernia123",
      "name": "AT-123",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-124",
      "x": 7,
      "y": 15,
      "area": "invernia124",
      "name": "AT-124",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-125",
      "x": 8,
      "y": 15,
      "area": "invernia125",
      "name": "AT-125",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-126",
      "x": 9,
      "y": 15,
      "area": "invernia126",
      "name": "AT-126",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-127",
      "x": 6,
      "y": 16,
      "area": "invernia127",
      "name": "AT-127",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    },
    {
      "code": "AT-128",
      "x": 8,
      "y": 16,
      "area": "invernia128",
      "name": "AT-128",
      "source": "runtime",
      "file": "data/world-map-v00163.js"
    }
  ],
  "quests": [
    {
      "id": "profession:farming:apprentice",
      "name": "Caminho do Agricultor — apprentice",
      "type": "profession",
      "npcKey": "alfredo",
      "giverDefinitionId": "alfredo",
      "stateKey": "professionQuests.farming.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "farming",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:farming:master",
      "name": "Caminho do Agricultor — master",
      "type": "profession",
      "npcKey": "alfredo",
      "giverDefinitionId": "alfredo",
      "stateKey": "professionQuests.farming.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "farming",
          "operator": "gte",
          "value": 45
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:farming:practitioner",
      "name": "Caminho do Agricultor — practitioner",
      "type": "profession",
      "npcKey": "alfredo",
      "giverDefinitionId": "alfredo",
      "stateKey": "professionQuests.farming.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "farming",
          "operator": "gte",
          "value": 15
        }
      ],
      "region": "Solacia"
    },
    {
      "id": "profession:farming:specialist",
      "name": "Caminho do Agricultor — specialist",
      "type": "profession",
      "npcKey": "alfredo",
      "giverDefinitionId": "alfredo",
      "stateKey": "professionQuests.farming.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "farming",
          "operator": "gte",
          "value": 30
        }
      ],
      "region": "Solacia"
    },
    {
      "id": "profession:alchemy:apprentice",
      "name": "Caminho do Alquimista — apprentice",
      "type": "profession",
      "npcKey": "witch",
      "giverDefinitionId": "witch",
      "stateKey": "professionQuests.alchemy.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "alchemy",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:alchemy:master",
      "name": "Caminho do Alquimista — master",
      "type": "profession",
      "npcKey": "witch",
      "giverDefinitionId": "witch",
      "stateKey": "professionQuests.alchemy.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "alchemy",
          "operator": "gte",
          "value": 45
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:alchemy:practitioner",
      "name": "Caminho do Alquimista — practitioner",
      "type": "profession",
      "npcKey": "witch",
      "giverDefinitionId": "witch",
      "stateKey": "professionQuests.alchemy.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "alchemy",
          "operator": "gte",
          "value": 15
        }
      ],
      "region": "Calindra"
    },
    {
      "id": "profession:alchemy:specialist",
      "name": "Caminho do Alquimista — specialist",
      "type": "profession",
      "npcKey": "witch",
      "giverDefinitionId": "witch",
      "stateKey": "professionQuests.alchemy.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "alchemy",
          "operator": "gte",
          "value": 30
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:crafting:apprentice",
      "name": "Caminho do Artesão — apprentice",
      "type": "profession",
      "npcKey": "gnome",
      "giverDefinitionId": "gnome",
      "stateKey": "professionQuests.crafting.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "crafting",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:crafting:master",
      "name": "Caminho do Artesão — master",
      "type": "profession",
      "npcKey": "gnome",
      "giverDefinitionId": "gnome",
      "stateKey": "professionQuests.crafting.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "crafting",
          "operator": "gte",
          "value": 50
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:crafting:practitioner",
      "name": "Caminho do Artesão — practitioner",
      "type": "profession",
      "npcKey": "gnome",
      "giverDefinitionId": "gnome",
      "stateKey": "professionQuests.crafting.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "crafting",
          "operator": "gte",
          "value": 20
        }
      ],
      "region": "Calindra"
    },
    {
      "id": "profession:crafting:specialist",
      "name": "Caminho do Artesão — specialist",
      "type": "profession",
      "npcKey": "gnome",
      "giverDefinitionId": "gnome",
      "stateKey": "professionQuests.crafting.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "crafting",
          "operator": "gte",
          "value": 35
        }
      ],
      "region": "Solacia"
    },
    {
      "id": "profession:cooking:apprentice",
      "name": "Caminho do Cozinheiro — apprentice",
      "type": "profession",
      "npcKey": "elder",
      "giverDefinitionId": "elder",
      "stateKey": "professionQuests.cooking.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "cooking",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:cooking:master",
      "name": "Caminho do Cozinheiro — master",
      "type": "profession",
      "npcKey": "elder",
      "giverDefinitionId": "elder",
      "stateKey": "professionQuests.cooking.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "cooking",
          "operator": "gte",
          "value": 50
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:cooking:practitioner",
      "name": "Caminho do Cozinheiro — practitioner",
      "type": "profession",
      "npcKey": "elder",
      "giverDefinitionId": "elder",
      "stateKey": "professionQuests.cooking.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "cooking",
          "operator": "gte",
          "value": 20
        }
      ],
      "region": "Mornaqua"
    },
    {
      "id": "profession:cooking:specialist",
      "name": "Caminho do Cozinheiro — specialist",
      "type": "profession",
      "npcKey": "elder",
      "giverDefinitionId": "elder",
      "stateKey": "professionQuests.cooking.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "cooking",
          "operator": "gte",
          "value": 35
        }
      ],
      "region": "Solacia"
    },
    {
      "id": "profession:smithing:apprentice",
      "name": "Caminho do Ferreiro — apprentice",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.smithing.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "smithing",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:smithing:master",
      "name": "Caminho do Ferreiro — master",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.smithing.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "smithing",
          "operator": "gte",
          "value": 50
        }
      ],
      "region": "Blaziria"
    },
    {
      "id": "profession:smithing:practitioner",
      "name": "Caminho do Ferreiro — practitioner",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.smithing.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "smithing",
          "operator": "gte",
          "value": 20
        }
      ],
      "region": "Invérnia"
    },
    {
      "id": "profession:smithing:specialist",
      "name": "Caminho do Ferreiro — specialist",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.smithing.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "smithing",
          "operator": "gte",
          "value": 35
        }
      ],
      "region": "Blaziria"
    },
    {
      "id": "profession:woodcutting:apprentice",
      "name": "Caminho do Lenhador — apprentice",
      "type": "profession",
      "npcKey": "farmer",
      "giverDefinitionId": "farmer",
      "stateKey": "professionQuests.woodcutting.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "woodcutting",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:woodcutting:master",
      "name": "Caminho do Lenhador — master",
      "type": "profession",
      "npcKey": "farmer",
      "giverDefinitionId": "farmer",
      "stateKey": "professionQuests.woodcutting.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "woodcutting",
          "operator": "gte",
          "value": 45
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:woodcutting:practitioner",
      "name": "Caminho do Lenhador — practitioner",
      "type": "profession",
      "npcKey": "farmer",
      "giverDefinitionId": "farmer",
      "stateKey": "professionQuests.woodcutting.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "woodcutting",
          "operator": "gte",
          "value": 15
        }
      ],
      "region": "Calindra"
    },
    {
      "id": "profession:woodcutting:specialist",
      "name": "Caminho do Lenhador — specialist",
      "type": "profession",
      "npcKey": "farmer",
      "giverDefinitionId": "farmer",
      "stateKey": "professionQuests.woodcutting.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "woodcutting",
          "operator": "gte",
          "value": 30
        }
      ],
      "region": "Calindra"
    },
    {
      "id": "profession:mining:apprentice",
      "name": "Caminho do Minerador — apprentice",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.mining.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "mining",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:mining:master",
      "name": "Caminho do Minerador — master",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.mining.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "mining",
          "operator": "gte",
          "value": 45
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:mining:practitioner",
      "name": "Caminho do Minerador — practitioner",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.mining.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "mining",
          "operator": "gte",
          "value": 15
        }
      ],
      "region": "Invérnia"
    },
    {
      "id": "profession:mining:specialist",
      "name": "Caminho do Minerador — specialist",
      "type": "profession",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "professionQuests.mining.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "mining",
          "operator": "gte",
          "value": 30
        }
      ],
      "region": "Blaziria"
    },
    {
      "id": "profession:fishing:apprentice",
      "name": "Caminho do Pescador — apprentice",
      "type": "profession",
      "npcKey": "clarisse",
      "giverDefinitionId": "clarisse",
      "stateKey": "professionQuests.fishing.apprentice",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "fishing",
          "operator": "gte",
          "value": 5
        }
      ],
      "region": "Atenaria"
    },
    {
      "id": "profession:fishing:master",
      "name": "Caminho do Pescador — master",
      "type": "profession",
      "npcKey": "clarisse",
      "giverDefinitionId": "clarisse",
      "stateKey": "professionQuests.fishing.master",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "fishing",
          "operator": "gte",
          "value": 45
        }
      ],
      "region": "Necrovícia"
    },
    {
      "id": "profession:fishing:practitioner",
      "name": "Caminho do Pescador — practitioner",
      "type": "profession",
      "npcKey": "clarisse",
      "giverDefinitionId": "clarisse",
      "stateKey": "professionQuests.fishing.practitioner",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "fishing",
          "operator": "gte",
          "value": 15
        }
      ],
      "region": "Mornaqua"
    },
    {
      "id": "profession:fishing:specialist",
      "name": "Caminho do Pescador — specialist",
      "type": "profession",
      "npcKey": "clarisse",
      "giverDefinitionId": "clarisse",
      "stateKey": "professionQuests.fishing.specialist",
      "doneAt": null,
      "source": "runtime",
      "file": "data/profession-quests.js",
      "screenCodes": [],
      "requirements": [
        {
          "type": "skill",
          "key": "fishing",
          "operator": "gte",
          "value": 30
        }
      ],
      "region": "Mornaqua"
    },
    {
      "id": "alfredo",
      "name": "Missão de Alfredo",
      "type": "side",
      "npcKey": "alfredo",
      "giverDefinitionId": "alfredo",
      "stateKey": "alfredoQuest",
      "doneAt": 2,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-006"
      ]
    },
    {
      "id": "elder",
      "name": "Missão de Anciã Mira",
      "type": "main",
      "npcKey": "elder",
      "giverDefinitionId": "elder",
      "stateKey": "quest",
      "doneAt": 3,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-006"
      ]
    },
    {
      "id": "witch",
      "name": "Missão de Bruxa Selene",
      "type": "side",
      "npcKey": "witch",
      "giverDefinitionId": "witch",
      "stateKey": "witchQuest",
      "doneAt": 3,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-011"
      ]
    },
    {
      "id": "clarisse",
      "name": "Missão de Clarisse",
      "type": "side",
      "npcKey": "clarisse",
      "giverDefinitionId": "clarisse",
      "stateKey": "clarisseQuest",
      "doneAt": 3,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-007"
      ]
    },
    {
      "id": "geraldo",
      "name": "Missão de Geraldo",
      "type": "side",
      "npcKey": "gatekeeper",
      "giverDefinitionId": "gatekeeper",
      "stateKey": "geraldoQuest",
      "doneAt": 2,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-011"
      ]
    },
    {
      "id": "gnome",
      "name": "Missão de Gnomo Júlio",
      "type": "side",
      "npcKey": "gnome",
      "giverDefinitionId": "gnome",
      "stateKey": "gnomeQuest",
      "doneAt": 2,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-014"
      ]
    },
    {
      "id": "heitor",
      "name": "Missão de Heitor",
      "type": "side",
      "npcKey": "heitor",
      "giverDefinitionId": "heitor",
      "stateKey": "heitorQuest",
      "doneAt": 2,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-005"
      ]
    },
    {
      "id": "farmer",
      "name": "Missão de Joaquim",
      "type": "side",
      "npcKey": "farmer",
      "giverDefinitionId": "farmer",
      "stateKey": "farmerQuest",
      "doneAt": 3,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-005"
      ]
    },
    {
      "id": "jordan",
      "name": "Missão de Jordan",
      "type": "side",
      "npcKey": "jordan",
      "giverDefinitionId": "jordan",
      "stateKey": "jordanQuest",
      "doneAt": 2,
      "source": "runtime",
      "file": "data/content.js",
      "screenCodes": [
        "AT-007"
      ]
    }
  ],
  "progression": [
    {
      "id": "endgame:master:smithing",
      "type": "masterQuest",
      "skill": "smithing",
      "level": 50,
      "label": "A Forja dos Oito Metais",
      "region": "",
      "requirements": {
        "skill": {
          "smithing": 50
        },
        "mastery": {
          "onyxBar": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:alchemy",
      "type": "masterQuest",
      "skill": "alchemy",
      "level": 45,
      "label": "A Fórmula Incompleta",
      "region": "",
      "requirements": {
        "skill": {
          "alchemy": 45
        },
        "mastery": {
          "antidoteElixir": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:artisanArchive",
      "type": "achievement",
      "skill": "crafting",
      "level": 50,
      "label": "Arquivo Completo",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:artisanVault",
      "type": "optionalArea",
      "skill": "crafting",
      "level": 50,
      "label": "Arquivo dos Artesãos",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:combatStyles",
      "type": "achievement",
      "skill": "combat",
      "level": 50,
      "label": "Arsenal Versátil",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:fishing",
      "type": "masterQuest",
      "skill": "fishing",
      "level": 45,
      "label": "As Oito Águas",
      "region": "",
      "requirements": {
        "skill": {
          "fishing": 45
        },
        "mastery": {
          "fishT8": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:recipe:masterFeast",
      "type": "specialRecipe",
      "skill": "cooking",
      "level": 45,
      "label": "Banquete das Regiões",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:collection:fish",
      "type": "collection",
      "skill": "fishing",
      "level": 40,
      "label": "Bestiário Aquático",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:tool:seedSatchel",
      "type": "advancedTool",
      "skill": "farming",
      "level": 50,
      "label": "Bolsa do Cultivador",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:ancientGrove",
      "type": "optionalArea",
      "skill": "woodcutting",
      "level": 50,
      "label": "Bosque Ancestral",
      "region": "Necrovícia",
      "requirements": {
        "skill": {
          "woodcutting": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:wood",
      "type": "masterQuest",
      "skill": "woodcutting",
      "level": 45,
      "label": "Bosque de Sete Madeiras",
      "region": "",
      "requirements": {
        "skill": {
          "woodcutting": 45
        },
        "mastery": {
          "darkEbonyWood": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:hunt",
      "type": "professionEncounter",
      "skill": "archery",
      "level": 55,
      "label": "Caçada do Horizonte",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:collection:recipes",
      "type": "collection",
      "skill": "cooking",
      "level": 40,
      "label": "Caderno Regional",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "skill:farming:5",
      "type": "skill",
      "skill": "farming",
      "level": 5,
      "label": "Caminho do Agricultor: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:farming:45",
      "type": "skill",
      "skill": "farming",
      "level": 45,
      "label": "Caminho do Agricultor: master",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:farming:15",
      "type": "skill",
      "skill": "farming",
      "level": 15,
      "label": "Caminho do Agricultor: practitioner",
      "region": "Solacia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:farming:30",
      "type": "skill",
      "skill": "farming",
      "level": 30,
      "label": "Caminho do Agricultor: specialist",
      "region": "Solacia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:alchemy:5",
      "type": "skill",
      "skill": "alchemy",
      "level": 5,
      "label": "Caminho do Alquimista: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:alchemy:45",
      "type": "skill",
      "skill": "alchemy",
      "level": 45,
      "label": "Caminho do Alquimista: master",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:alchemy:15",
      "type": "skill",
      "skill": "alchemy",
      "level": 15,
      "label": "Caminho do Alquimista: practitioner",
      "region": "Calindra",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:alchemy:30",
      "type": "skill",
      "skill": "alchemy",
      "level": 30,
      "label": "Caminho do Alquimista: specialist",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:crafting:5",
      "type": "skill",
      "skill": "crafting",
      "level": 5,
      "label": "Caminho do Artesão: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:crafting:50",
      "type": "skill",
      "skill": "crafting",
      "level": 50,
      "label": "Caminho do Artesão: master",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:crafting:20",
      "type": "skill",
      "skill": "crafting",
      "level": 20,
      "label": "Caminho do Artesão: practitioner",
      "region": "Calindra",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:crafting:35",
      "type": "skill",
      "skill": "crafting",
      "level": 35,
      "label": "Caminho do Artesão: specialist",
      "region": "Solacia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:cooking:5",
      "type": "skill",
      "skill": "cooking",
      "level": 5,
      "label": "Caminho do Cozinheiro: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:cooking:50",
      "type": "skill",
      "skill": "cooking",
      "level": 50,
      "label": "Caminho do Cozinheiro: master",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:cooking:20",
      "type": "skill",
      "skill": "cooking",
      "level": 20,
      "label": "Caminho do Cozinheiro: practitioner",
      "region": "Mornaqua",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:cooking:35",
      "type": "skill",
      "skill": "cooking",
      "level": 35,
      "label": "Caminho do Cozinheiro: specialist",
      "region": "Solacia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:smithing:5",
      "type": "skill",
      "skill": "smithing",
      "level": 5,
      "label": "Caminho do Ferreiro: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:smithing:50",
      "type": "skill",
      "skill": "smithing",
      "level": 50,
      "label": "Caminho do Ferreiro: master",
      "region": "Blaziria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:smithing:20",
      "type": "skill",
      "skill": "smithing",
      "level": 20,
      "label": "Caminho do Ferreiro: practitioner",
      "region": "Invérnia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:smithing:35",
      "type": "skill",
      "skill": "smithing",
      "level": 35,
      "label": "Caminho do Ferreiro: specialist",
      "region": "Blaziria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:woodcutting:5",
      "type": "skill",
      "skill": "woodcutting",
      "level": 5,
      "label": "Caminho do Lenhador: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:woodcutting:45",
      "type": "skill",
      "skill": "woodcutting",
      "level": 45,
      "label": "Caminho do Lenhador: master",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:woodcutting:15",
      "type": "skill",
      "skill": "woodcutting",
      "level": 15,
      "label": "Caminho do Lenhador: practitioner",
      "region": "Calindra",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:woodcutting:30",
      "type": "skill",
      "skill": "woodcutting",
      "level": 30,
      "label": "Caminho do Lenhador: specialist",
      "region": "Calindra",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:mining:5",
      "type": "skill",
      "skill": "mining",
      "level": 5,
      "label": "Caminho do Minerador: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:mining:45",
      "type": "skill",
      "skill": "mining",
      "level": 45,
      "label": "Caminho do Minerador: master",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:mining:15",
      "type": "skill",
      "skill": "mining",
      "level": 15,
      "label": "Caminho do Minerador: practitioner",
      "region": "Invérnia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:mining:30",
      "type": "skill",
      "skill": "mining",
      "level": 30,
      "label": "Caminho do Minerador: specialist",
      "region": "Blaziria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:fishing:5",
      "type": "skill",
      "skill": "fishing",
      "level": 5,
      "label": "Caminho do Pescador: apprentice",
      "region": "Atenaria",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:fishing:45",
      "type": "skill",
      "skill": "fishing",
      "level": 45,
      "label": "Caminho do Pescador: master",
      "region": "Necrovícia",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:fishing:15",
      "type": "skill",
      "skill": "fishing",
      "level": 15,
      "label": "Caminho do Pescador: practitioner",
      "region": "Mornaqua",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "skill:fishing:30",
      "type": "skill",
      "skill": "fishing",
      "level": 30,
      "label": "Caminho do Pescador: specialist",
      "region": "Mornaqua",
      "source": "runtime",
      "file": "data/profession-quests.js"
    },
    {
      "id": "endgame:area:masterField",
      "type": "optionalArea",
      "skill": "farming",
      "level": 50,
      "label": "Campo Experimental",
      "region": "",
      "requirements": {
        "skill": {
          "farming": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:reagents",
      "type": "achievement",
      "skill": "alchemy",
      "level": 50,
      "label": "Catálogo de Reagentes",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:champions",
      "type": "professionEncounter",
      "skill": "combat",
      "level": 55,
      "label": "Círculo dos Campeões",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:collection:crops",
      "type": "collection",
      "skill": "farming",
      "level": 40,
      "label": "Coleção de Safras",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:collection:minerals",
      "type": "collection",
      "skill": "mining",
      "level": 40,
      "label": "Coleção Mineralógica",
      "region": "",
      "requirements": {
        "skill": {
          "mining": 40
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:magic",
      "type": "masterQuest",
      "skill": "magic",
      "level": 45,
      "label": "Convergência Arcana",
      "region": "",
      "requirements": {
        "skill": {
          "magic": 45
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:festivalKitchen",
      "type": "professionEncounter",
      "skill": "cooking",
      "level": 50,
      "label": "Cozinha do Festival",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:cooking",
      "type": "masteryChallenge",
      "skill": "cooking",
      "level": 50,
      "label": "Cozinha Versátil",
      "region": "",
      "requirements": {
        "masteryTotal": 70
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:combat",
      "type": "masterQuest",
      "skill": "combat",
      "level": 50,
      "label": "Disciplina do Veterano",
      "region": "",
      "requirements": {
        "skill": {
          "combat": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:alchemy",
      "type": "masteryChallenge",
      "skill": "alchemy",
      "level": 50,
      "label": "Dosagem Perfeita",
      "region": "",
      "requirements": {
        "masteryTotal": 60
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:arcaneEcho",
      "type": "professionEncounter",
      "skill": "magic",
      "level": 50,
      "label": "Eco Arcano",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:riverSpirit",
      "type": "professionEncounter",
      "skill": "fishing",
      "level": 50,
      "label": "Espírito das Águas",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:schools",
      "type": "achievement",
      "skill": "magic",
      "level": 50,
      "label": "Estudioso das Escolas",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:arcaneRift",
      "type": "optionalArea",
      "skill": "magic",
      "level": 50,
      "label": "Fenda Arcana",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:arrows",
      "type": "achievement",
      "skill": "archery",
      "level": 50,
      "label": "Flechas para Toda Ocasião",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:smithing",
      "type": "masteryChallenge",
      "skill": "smithing",
      "level": 55,
      "label": "Forjador Versátil",
      "region": "",
      "requirements": {
        "masteryTotal": 80
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:deepMine",
      "type": "optionalArea",
      "skill": "mining",
      "level": 50,
      "label": "Galeria Profunda",
      "region": "Necrovícia",
      "requirements": {
        "skill": {
          "mining": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:stoneWarden",
      "type": "professionEncounter",
      "skill": "mining",
      "level": 50,
      "label": "Guardião do Veio",
      "region": "",
      "requirements": {
        "skill": {
          "mining": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:collection:woods",
      "type": "collection",
      "skill": "woodcutting",
      "level": 40,
      "label": "Herbário de Madeiras",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:alchemistGarden",
      "type": "optionalArea",
      "skill": "alchemy",
      "level": 50,
      "label": "Jardim Alquímico",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:recipe:masterRepairKit",
      "type": "specialRecipe",
      "skill": "smithing",
      "level": 45,
      "label": "Kit de Manutenção do Mestre",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:tool:precisionKit",
      "type": "advancedTool",
      "skill": "crafting",
      "level": 50,
      "label": "Kit de Precisão",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:tool:forester",
      "type": "advancedTool",
      "skill": "woodcutting",
      "level": 50,
      "label": "Machado do Silvicultor",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:wood",
      "type": "masteryChallenge",
      "skill": "woodcutting",
      "level": 50,
      "label": "Manejo Perfeito",
      "region": "",
      "requirements": {
        "masteryTotal": 70
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:cosmetic:masterMantle",
      "type": "cosmetic",
      "skill": "crafting",
      "level": 50,
      "label": "Manto dos Mestres",
      "region": "",
      "requirements": {
        "achievements": 3
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:crafting",
      "type": "masteryChallenge",
      "skill": "crafting",
      "level": 50,
      "label": "Mãos de Muitos Ofícios",
      "region": "",
      "requirements": {
        "masteryTotal": 75
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:tool:masterHammer",
      "type": "advancedTool",
      "skill": "smithing",
      "level": 55,
      "label": "Martelo de Mestre",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:cooking",
      "type": "masterQuest",
      "skill": "cooking",
      "level": 50,
      "label": "Mesa de Terrópia",
      "region": "",
      "requirements": {
        "skill": {
          "cooking": 50
        },
        "mastery": {
          "cookedFishT8": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:recipe:travelerTable",
      "type": "specialRecipe",
      "skill": "cooking",
      "level": 45,
      "label": "Mesa do Viajante",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:unstableMixture",
      "type": "professionEncounter",
      "skill": "alchemy",
      "level": 50,
      "label": "Mistura Instável",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:mining",
      "type": "masterQuest",
      "skill": "mining",
      "level": 45,
      "label": "O Último Veio",
      "region": "Necrovícia",
      "requirements": {
        "skill": {
          "mining": 45
        },
        "mastery": {
          "onyxOre": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:crafting",
      "type": "masterQuest",
      "skill": "crafting",
      "level": 50,
      "label": "Obra-Prima do Artesão",
      "region": "",
      "requirements": {
        "skill": {
          "crafting": 50
        },
        "mastery": {
          "onyxGemAmulet": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:archery",
      "type": "masterQuest",
      "skill": "archery",
      "level": 50,
      "label": "Olho do Mestre",
      "region": "",
      "requirements": {
        "skill": {
          "archery": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:fishing",
      "type": "masteryChallenge",
      "skill": "fishing",
      "level": 50,
      "label": "Pescador de Ecossistemas",
      "region": "",
      "requirements": {
        "masteryTotal": 70
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:tool:prospector",
      "type": "advancedTool",
      "skill": "mining",
      "level": 50,
      "label": "Picareta do Prospector",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:area:abyssalPool",
      "type": "optionalArea",
      "skill": "fishing",
      "level": 50,
      "label": "Poço Abissal",
      "region": "Necrovícia",
      "requirements": {
        "skill": {
          "fishing": 50
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:encounter:forgeTrial",
      "type": "professionEncounter",
      "skill": "smithing",
      "level": 55,
      "label": "Prova da Forja Viva",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:recipe:regionalRelic",
      "type": "specialRecipe",
      "skill": "crafting",
      "level": 45,
      "label": "Relíquia das Regiões",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:master:farming",
      "type": "masterQuest",
      "skill": "farming",
      "level": 45,
      "label": "Safra do Mestre",
      "region": "",
      "requirements": {
        "skill": {
          "farming": 45
        },
        "mastery": {
          "wheat": 15
        }
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:achievement:sevenMetals",
      "type": "achievement",
      "skill": "smithing",
      "level": 50,
      "label": "Sete Metais",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:mining",
      "type": "masteryChallenge",
      "skill": "mining",
      "level": 50,
      "label": "Sete Veios, Um Ofício",
      "region": "",
      "requirements": {
        "skill": {
          "mining": 50
        },
        "masteryTotal": 70
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:mastery:farming",
      "type": "masteryChallenge",
      "skill": "farming",
      "level": 50,
      "label": "Solo Conhecido",
      "region": "",
      "requirements": {
        "masteryTotal": 55
      },
      "source": "runtime",
      "file": "data/skill-endgame.js"
    },
    {
      "id": "endgame:recipe:explorerTonic",
      "type": "specialRecipe",
      "skill": "alchemy",
      "level": 45,
      "label": "Tônico do Explorador",
      "region": "",
      "requirements": {},
      "source": "runtime",
      "file": "data/skill-endgame.js"
    }
  ],
  "npcs": [
    {
      "id": "alfredo",
      "name": "Alfredo",
      "label": "👨‍🌾 Alfredo",
      "detail": "runtime NPC · village2",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 13,
          "y": 10,
          "instanceId": "alfredo"
        }
      ]
    },
    {
      "id": "elder",
      "name": "Anciã Mira",
      "label": "🧓 Anciã Mira",
      "detail": "runtime NPC · village2",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 26,
          "y": 9,
          "instanceId": "elder"
        }
      ]
    },
    {
      "id": "witch",
      "name": "Bruxa Selene",
      "label": "🧙‍♀️ Bruxa Selene",
      "detail": "runtime NPC · witchyard",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "witchyard",
          "screenCode": "AT-011",
          "x": 8,
          "y": 4,
          "instanceId": "witch"
        }
      ]
    },
    {
      "id": "carlos",
      "name": "Carlos",
      "label": "🧑‍💼 Carlos",
      "detail": "runtime NPC · bank",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 8,
          "y": 6,
          "instanceId": "carlos"
        }
      ]
    },
    {
      "id": "cecilia",
      "name": "Cecília",
      "label": "🧑‍💼 Cecília",
      "detail": "runtime NPC · bank",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 16,
          "y": 6,
          "instanceId": "cecilia"
        }
      ]
    },
    {
      "id": "clarisse",
      "name": "Clarisse",
      "label": "👧 Clarisse",
      "detail": "runtime NPC · entrance",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 11,
          "y": 5,
          "instanceId": "clarisse"
        }
      ]
    },
    {
      "id": "clovis",
      "name": "Clóvis",
      "label": "🧑‍💼 Clóvis",
      "detail": "runtime NPC · bank",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 24,
          "y": 6,
          "instanceId": "clovis"
        }
      ]
    },
    {
      "id": "elis",
      "name": "Elis",
      "label": "🧪 Elis",
      "detail": "runtime NPC · elisCabin · loja alchemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "elisCabin",
          "screenCode": "",
          "x": 16,
          "y": 10,
          "instanceId": "elis"
        }
      ]
    },
    {
      "id": "gatekeeper",
      "name": "Geraldo",
      "label": "🧙‍♂️ Geraldo",
      "detail": "runtime NPC · witchyard",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "witchyard",
          "screenCode": "AT-011",
          "x": 8,
          "y": 6,
          "instanceId": "gatekeeper"
        }
      ]
    },
    {
      "id": "gnome",
      "name": "Gnomo Júlio",
      "label": "🧙‍♂️ Gnomo Júlio",
      "detail": "runtime NPC · mushroomforest",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 18,
          "y": 10,
          "instanceId": "gnome"
        }
      ]
    },
    {
      "id": "heitor",
      "name": "Heitor",
      "label": "🧒 Heitor",
      "detail": "runtime NPC · village",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 10,
          "y": 5,
          "instanceId": "heitor"
        }
      ]
    },
    {
      "id": "farmer",
      "name": "Joaquim",
      "label": "👨‍🌾 Joaquim",
      "detail": "runtime NPC · village",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 5,
          "y": 8,
          "instanceId": "farmer"
        }
      ]
    },
    {
      "id": "jordan",
      "name": "Jordan",
      "label": "👴 Jordan",
      "detail": "runtime NPC · entrance",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 6,
          "y": 5,
          "instanceId": "jordan"
        }
      ]
    },
    {
      "id": "shop",
      "name": "Lojista",
      "label": "🧑‍💼 Lojista",
      "detail": "runtime NPC · shopInterior · loja general",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "shopInterior",
          "screenCode": "AT-004",
          "x": 16,
          "y": 8,
          "instanceId": "shop"
        }
      ]
    }
  ],
  "resources": [
    {
      "id": "chest",
      "name": "Baú",
      "label": "🧰 Baú / recompensa",
      "detail": "Recurso interagível com loot",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "witchyard",
          "screenCode": "AT-011",
          "x": 13,
          "y": 2,
          "instanceId": "witchChest"
        },
        {
          "area": "cave2",
          "screenCode": "AT-009",
          "x": 26,
          "y": 7,
          "instanceId": "cave2Chest"
        }
      ]
    },
    {
      "id": "tree:iron",
      "name": "Carvalho",
      "label": "🌳 Carvalho",
      "detail": "Woodcutting · material iron · Lenha de Carvalho",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 9,
          "y": 1,
          "instanceId": "treeIron1"
        },
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 14,
          "y": 2,
          "instanceId": "treeIron2"
        },
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 24,
          "y": 9,
          "instanceId": "treeIron3"
        },
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 2,
          "y": 11,
          "instanceId": "treeIron4"
        },
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 14,
          "y": 11,
          "instanceId": "v2Oak1"
        },
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 5,
          "y": 2,
          "instanceId": "v2Oak2"
        },
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 8,
          "y": 1,
          "instanceId": "v2Oak3"
        },
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 3,
          "y": 13,
          "instanceId": "entranceOak1"
        },
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 8,
          "y": 15,
          "instanceId": "entranceOak2"
        },
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 14,
          "y": 13,
          "instanceId": "entranceOak3"
        },
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 4,
          "y": 12,
          "instanceId": "mushOak1"
        },
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 26,
          "y": 14,
          "instanceId": "mushOak2"
        }
      ]
    },
    {
      "id": "berry:mushroom",
      "name": "Cogumelo",
      "label": "🍄 Cogumelo",
      "detail": "Coleta · mushroom",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 10,
          "y": 6,
          "instanceId": "mush1"
        },
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 22,
          "y": 14,
          "instanceId": "mush2"
        }
      ]
    },
    {
      "id": "berry:raspberry",
      "name": "Framboesa",
      "label": "🫐 Framboesa",
      "detail": "Coleta · raspberry",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 12,
          "y": 5,
          "instanceId": "rasp1"
        },
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 20,
          "y": 10,
          "instanceId": "rasp2"
        },
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 29,
          "y": 6,
          "instanceId": "rasp3"
        }
      ]
    },
    {
      "id": "berry:blueRaspberry",
      "name": "Framboesa Azul",
      "label": "🔵 Framboesa Azul",
      "detail": "Coleta · blueRaspberry",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "spiderlair",
          "screenCode": "AT-013",
          "x": 13,
          "y": 4,
          "instanceId": "blueRasp"
        }
      ]
    },
    {
      "id": "sunflower",
      "name": "Girassol",
      "label": "🌻 Girassol",
      "detail": "Coleta · sunflower",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "atenaria022",
          "screenCode": "AT-022",
          "x": 5,
          "y": 5,
          "instanceId": "girassol1"
        },
        {
          "area": "atenaria022",
          "screenCode": "AT-022",
          "x": 9,
          "y": 13,
          "instanceId": "girassol2"
        },
        {
          "area": "atenaria022",
          "screenCode": "AT-022",
          "x": 27,
          "y": 12,
          "instanceId": "girassol3"
        }
      ]
    },
    {
      "id": "ore:iron",
      "name": "Minério de Ferro",
      "label": "⛏️ Minério de Ferro",
      "detail": "Mining · material iron",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 4,
          "y": 4,
          "instanceId": "iron1"
        },
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 10,
          "y": 14,
          "instanceId": "iron2"
        },
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 18,
          "y": 4,
          "instanceId": "iron3"
        },
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 23,
          "y": 14,
          "instanceId": "iron4"
        },
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 28,
          "y": 5,
          "instanceId": "iron5"
        }
      ]
    },
    {
      "id": "ore:mithril",
      "name": "Minério de Mithril",
      "label": "⛏️ Minério de Mithril",
      "detail": "Mining · material mithril",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave2",
          "screenCode": "AT-009",
          "x": 24,
          "y": 14,
          "instanceId": "mithril1"
        }
      ]
    },
    {
      "id": "ore:platinum",
      "name": "Minério de Platina",
      "label": "⛏️ Minério de Platina",
      "detail": "Mining · material platinum",
      "file": "data/content.js · data/resources.js",
      "source": "runtime",
      "instances": [
        {
          "area": "spiderlair",
          "screenCode": "AT-013",
          "x": 11,
          "y": 2,
          "instanceId": "platinumSpider1"
        },
        {
          "area": "spiderlair",
          "screenCode": "AT-013",
          "x": 12,
          "y": 6,
          "instanceId": "platinumSpider2"
        }
      ]
    }
  ],
  "enemies": [
    {
      "id": "spider2",
      "name": "Aranha da Névoa",
      "label": "🕷️ Aranha da Névoa",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "darkforest",
          "screenCode": "AT-012",
          "x": 7,
          "y": 2,
          "instanceId": "spider2"
        }
      ]
    },
    {
      "id": "spider3",
      "name": "Aranha Espinhosa",
      "label": "🕷️ Aranha Espinhosa",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "darkforest",
          "screenCode": "AT-012",
          "x": 10,
          "y": 6,
          "instanceId": "spider3"
        }
      ]
    },
    {
      "id": "giantSpider",
      "name": "Aranha Gigante",
      "label": "🕷️ Aranha Gigante",
      "detail": "runtime enemy · chefe",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "spiderlair",
          "screenCode": "AT-013",
          "x": 8,
          "y": 4,
          "instanceId": "giantSpider"
        }
      ]
    },
    {
      "id": "spider1",
      "name": "Aranha Sombria",
      "label": "🕷️ Aranha Sombria",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "darkforest",
          "screenCode": "AT-012",
          "x": 4,
          "y": 4,
          "instanceId": "spider1"
        }
      ]
    },
    {
      "id": "spider4",
      "name": "Aranha Venenosa",
      "label": "🕷️ Aranha Venenosa",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "darkforest",
          "screenCode": "AT-012",
          "x": 13,
          "y": 4,
          "instanceId": "spider4"
        }
      ]
    },
    {
      "id": "goat",
      "name": "Bode",
      "label": "🐐 Bode",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "random",
          "screenCode": "",
          "x": -1,
          "y": -1,
          "instanceId": "goat"
        }
      ]
    },
    {
      "id": "capybara1",
      "name": "Capivara",
      "label": "🟤 Capivara",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 8,
          "y": 15,
          "instanceId": "capybara1"
        }
      ]
    },
    {
      "id": "capybara2",
      "name": "Capivara",
      "label": "🟤 Capivara",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "mushroomforest",
          "screenCode": "AT-014",
          "x": 24,
          "y": 7,
          "instanceId": "capybara2"
        }
      ]
    },
    {
      "id": "dragon",
      "name": "Dragão Ancestral",
      "label": "🐉 Dragão Ancestral",
      "detail": "runtime enemy · chefe",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "random",
          "screenCode": "",
          "x": -1,
          "y": -1,
          "instanceId": "dragon"
        }
      ]
    },
    {
      "id": "chicken1",
      "name": "Galinha",
      "label": "🐔 Galinha",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 2,
          "y": 2,
          "instanceId": "chicken1"
        }
      ]
    },
    {
      "id": "chicken2",
      "name": "Galinha",
      "label": "🐔 Galinha",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 5,
          "y": 3,
          "instanceId": "chicken2"
        }
      ]
    },
    {
      "id": "chicken3",
      "name": "Galinha",
      "label": "🐔 Galinha",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village",
          "screenCode": "AT-005",
          "x": 3,
          "y": 5,
          "instanceId": "chicken3"
        }
      ]
    },
    {
      "id": "caveWolf2",
      "name": "Lobo Cinzento",
      "label": "🐺 Lobo Cinzento",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave2",
          "screenCode": "AT-009",
          "x": 18,
          "y": 13,
          "instanceId": "caveWolf2"
        }
      ]
    },
    {
      "id": "caveWolf1",
      "name": "Lobo da Caverna",
      "label": "🐺 Lobo da Caverna",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave2",
          "screenCode": "AT-009",
          "x": 10,
          "y": 8,
          "instanceId": "caveWolf1"
        }
      ]
    },
    {
      "id": "caveWolf3",
      "name": "Lobo Feroz",
      "label": "🐺 Lobo Feroz",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave3",
          "screenCode": "AT-010",
          "x": 12,
          "y": 6,
          "instanceId": "caveWolf3"
        }
      ]
    },
    {
      "id": "wolf",
      "name": "Lobo Gigante",
      "label": "🐺 Lobo Gigante",
      "detail": "runtime enemy · chefe",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave3",
          "screenCode": "AT-010",
          "x": 23,
          "y": 8,
          "instanceId": "wolf"
        }
      ]
    },
    {
      "id": "wolfGuard",
      "name": "Lobo Guardião",
      "label": "🐺 Lobo Guardião",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave2",
          "screenCode": "AT-009",
          "x": 22,
          "y": 8,
          "instanceId": "wolfGuard"
        }
      ]
    },
    {
      "id": "caveWolf4",
      "name": "Lobo Sombrio",
      "label": "🐺 Lobo Sombrio",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave3",
          "screenCode": "AT-010",
          "x": 17,
          "y": 14,
          "instanceId": "caveWolf4"
        }
      ]
    },
    {
      "id": "b4",
      "name": "Morcego Cinzento",
      "label": "🦇 Morcego Cinzento",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 25,
          "y": 15,
          "instanceId": "b4"
        }
      ]
    },
    {
      "id": "b2",
      "name": "Morcego da Caverna",
      "label": "🦇 Morcego da Caverna",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 14,
          "y": 10,
          "instanceId": "b2"
        }
      ]
    },
    {
      "id": "b3",
      "name": "Morcego Feroz",
      "label": "🦇 Morcego Feroz",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 20,
          "y": 8,
          "instanceId": "b3"
        }
      ]
    },
    {
      "id": "b1",
      "name": "Morcego Sombrio",
      "label": "🦇 Morcego Sombrio",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "cave1",
          "screenCode": "AT-008",
          "x": 6,
          "y": 4,
          "instanceId": "b1"
        }
      ]
    },
    {
      "id": "rat",
      "name": "Rato Gigante",
      "label": "🐀 Rato Gigante",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 13,
          "y": 8,
          "instanceId": "rat"
        }
      ]
    },
    {
      "id": "rat2",
      "name": "Rato Gigante",
      "label": "🐀 Rato Gigante",
      "detail": "runtime enemy",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "entrance",
          "screenCode": "AT-007",
          "x": 5,
          "y": 7,
          "instanceId": "rat2"
        }
      ]
    },
    {
      "id": "s4",
      "name": "Slime Antigo",
      "label": "🟣 Slime Antigo",
      "detail": "runtime enemy · família slime",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 13,
          "y": 3,
          "instanceId": "s4"
        }
      ]
    },
    {
      "id": "s2",
      "name": "Slime Azul",
      "label": "🔵 Slime Azul",
      "detail": "runtime enemy · família slime",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 8,
          "y": 5,
          "instanceId": "s2"
        }
      ]
    },
    {
      "id": "s1",
      "name": "Slime do Musgo",
      "label": "🟢 Slime do Musgo",
      "detail": "runtime enemy · família slime",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 2,
          "y": 5,
          "instanceId": "s1"
        }
      ]
    },
    {
      "id": "s3",
      "name": "Slime Rubro",
      "label": "🔴 Slime Rubro",
      "detail": "runtime enemy · família slime",
      "file": "data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "village2",
          "screenCode": "AT-006",
          "x": 10,
          "y": 5,
          "instanceId": "s3"
        }
      ]
    }
  ],
  "buildings": [
    {
      "id": "bank",
      "name": "Banco",
      "label": "🏦 Banco",
      "detail": "runtime location · bank",
      "file": "data/locations.js · data/content.js",
      "source": "runtime",
      "instances": [
        {
          "screenCode": "AT-003",
          "area": "bank"
        },
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 8,
          "y": 6,
          "instanceId": "carlos",
          "kind": "npc-anchor"
        },
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 16,
          "y": 6,
          "instanceId": "cecilia",
          "kind": "npc-anchor"
        },
        {
          "area": "bank",
          "screenCode": "AT-003",
          "x": 24,
          "y": 6,
          "instanceId": "clovis",
          "kind": "npc-anchor"
        }
      ]
    },
    {
      "id": "elis-cabin",
      "name": "Cabana da Alquimista",
      "label": "🧪 Cabana da Alquimista",
      "detail": "runtime location · elisCabin",
      "file": "data/locations.js · data/content.js",
      "source": "runtime",
      "instances": [
        {
          "area": "elisCabin",
          "screenCode": "",
          "x": 16,
          "y": 10,
          "instanceId": "elis",
          "kind": "npc-anchor"
        }
      ]
    },
    {
      "id": "player-house",
      "name": "Casa do Jogador",
      "label": "🏠 Casa do Jogador",
      "detail": "runtime location · home",
      "file": "data/locations.js · data/content.js",
      "source": "runtime",
      "instances": [
        {
          "screenCode": "AT-001",
          "area": "home"
        }
      ]
    },
    {
      "id": "smithy",
      "name": "Ferraria",
      "label": "🔥 Ferraria",
      "detail": "runtime location · smithy",
      "file": "data/locations.js · data/content.js",
      "source": "runtime",
      "instances": [
        {
          "screenCode": "AT-002",
          "area": "smithy"
        }
      ]
    },
    {
      "id": "shop",
      "name": "Loja",
      "label": "🏪 Loja",
      "detail": "runtime location · shopInterior",
      "file": "data/locations.js · data/content.js",
      "source": "runtime",
      "instances": [
        {
          "screenCode": "AT-004",
          "area": "shopInterior"
        },
        {
          "area": "shopInterior",
          "screenCode": "AT-004",
          "x": 16,
          "y": 8,
          "instanceId": "shop",
          "kind": "npc-anchor"
        }
      ]
    }
  ],
  "mechanics": [
    {
      "id": "bank",
      "name": "Banco",
      "label": "🏦 Banco",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "chest",
      "name": "Baú / recompensa",
      "label": "🧰 Baú / recompensa",
      "detail": "detectado no runtime · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "weather",
      "name": "Clima",
      "label": "🌦️ Clima",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "combat",
      "name": "Combate",
      "label": "⚙️ Combate",
      "detail": "detectado no runtime · js/battle.js",
      "file": "js/battle.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "crafting",
      "name": "Crafting",
      "label": "🛠️ Crafting",
      "detail": "detectado no runtime · js/crafting.js",
      "file": "js/crafting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "cooking",
      "name": "Culinária",
      "label": "🍳 Culinária",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "cutscene",
      "name": "Cutscene scriptada",
      "label": "⚙️ Cutscene scriptada",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "smithing",
      "name": "Ferraria",
      "label": "🔥 Ferraria",
      "detail": "detectado no runtime · data/equipment.js",
      "file": "data/equipment.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "shop",
      "name": "Loja",
      "label": "🏪 Loja",
      "detail": "detectado no runtime · data/economy.js",
      "file": "data/economy.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "quest-marker",
      "name": "Marcador de Quest",
      "label": "⚙️ Marcador de Quest",
      "detail": "detectado no runtime · js/quest.js",
      "file": "js/quest.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "npc-context-menu",
      "name": "Menu contextual de NPC",
      "label": "🖱️ Menu contextual de NPC",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "npc-dialogue",
      "name": "NPC + diálogo",
      "label": "⚙️ NPC + diálogo",
      "detail": "detectado no runtime · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fishing",
      "name": "Pesca",
      "label": "🎣 Pesca",
      "detail": "detectado no runtime · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "farming",
      "name": "Plantação",
      "label": "🌱 Plantação",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "attack-potion",
      "name": "Poção de Ataque",
      "label": "🧪 Poção de Ataque",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "door-interior",
      "name": "Porta / Interior",
      "label": "🚪 Porta / Interior",
      "detail": "detectado no runtime · data/map-codes.js",
      "file": "data/map-codes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "world-project",
      "name": "Projeto de Mundo",
      "label": "🏗️ Projeto de Mundo",
      "detail": "detectado no runtime · data/world-projects.js",
      "file": "data/world-projects.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "skill-check",
      "name": "Skill Check",
      "label": "🎯 Skill Check",
      "detail": "detectado no runtime · data/quest-skill-checks.js",
      "file": "data/quest-skill-checks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "screen-transition",
      "name": "Transição por borda",
      "label": "⚙️ Transição por borda",
      "detail": "detectado no runtime · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    }
  ],
  "runtime": [
    {
      "id": "fn:battle-visuals.js:ability",
      "name": "ability",
      "label": "ƒ ability",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:accentFrame",
      "name": "accentFrame",
      "label": "ƒ accentFrame",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:accessiblePrefix",
      "name": "accessiblePrefix",
      "label": "ƒ accessiblePrefix",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:gathering-vfx.js:activeCount",
      "name": "activeCount",
      "label": "ƒ activeCount",
      "detail": "função detectada · js/gathering-vfx.js",
      "file": "js/gathering-vfx.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:activeFoodBuff",
      "name": "activeFoodBuff",
      "label": "ƒ activeFoodBuff",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:actorPose",
      "name": "actorPose",
      "label": "ƒ actorPose",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:addFloater",
      "name": "addFloater",
      "label": "ƒ addFloater",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:addFx",
      "name": "addFx",
      "label": "ƒ addFx",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:adjustHex",
      "name": "adjustHex",
      "label": "ƒ adjustHex",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:gathering-vfx.js:alloc",
      "name": "alloc",
      "label": "ƒ alloc",
      "detail": "função detectada · js/gathering-vfx.js",
      "file": "js/gathering-vfx.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:ambientFxScale",
      "name": "ambientFxScale",
      "label": "ƒ ambientFxScale",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-autotile.js:analyze",
      "name": "analyze",
      "label": "ƒ analyze",
      "detail": "função detectada · js/terrain-autotile.js",
      "file": "js/terrain-autotile.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:applyAccessibility",
      "name": "applyAccessibility",
      "label": "ƒ applyAccessibility",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:armorTypeFor",
      "name": "armorTypeFor",
      "label": "ƒ armorTypeFor",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:autoCameraZoom",
      "name": "autoCameraZoom",
      "label": "ƒ autoCameraZoom",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:backupKey",
      "name": "backupKey",
      "label": "ƒ backupKey",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:backupKeyIfPresent",
      "name": "backupKeyIfPresent",
      "label": "ƒ backupKeyIfPresent",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:backupRaw",
      "name": "backupRaw",
      "label": "ƒ backupRaw",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:backups",
      "name": "backups",
      "label": "ƒ backups",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:barTypeFor",
      "name": "barTypeFor",
      "label": "ƒ barTypeFor",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:baseHuman",
      "name": "baseHuman",
      "label": "ƒ baseHuman",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:begin",
      "name": "begin",
      "label": "ƒ begin",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:begin",
      "name": "begin",
      "label": "ƒ begin",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:bestTool",
      "name": "bestTool",
      "label": "ƒ bestTool",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:bind",
      "name": "bind",
      "label": "ƒ bind",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:bind",
      "name": "bind",
      "label": "ƒ bind",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:boundedCacheSet",
      "name": "boundedCacheSet",
      "label": "ƒ boundedCacheSet",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:boundedSet",
      "name": "boundedSet",
      "label": "ƒ boundedSet",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:burst",
      "name": "burst",
      "label": "ƒ burst",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:cache",
      "name": "cache",
      "label": "ƒ cache",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:cacheStats",
      "name": "cacheStats",
      "label": "ƒ cacheStats",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:cameraLookAhead",
      "name": "cameraLookAhead",
      "label": "ƒ cameraLookAhead",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:cameraViewport",
      "name": "cameraViewport",
      "label": "ƒ cameraViewport",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:cameraZoom",
      "name": "cameraZoom",
      "label": "ƒ cameraZoom",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:canvas",
      "name": "canvas",
      "label": "ƒ canvas",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:chooseBackend",
      "name": "chooseBackend",
      "label": "ƒ chooseBackend",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:clamp",
      "name": "clamp",
      "label": "ƒ clamp",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:clamp",
      "name": "clamp",
      "label": "ƒ clamp",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:clamp",
      "name": "clamp",
      "label": "ƒ clamp",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:shadow-system.js:clamp",
      "name": "clamp",
      "label": "ƒ clamp",
      "detail": "função detectada · js/shadow-system.js",
      "file": "js/shadow-system.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:clamp",
      "name": "clamp",
      "label": "ƒ clamp",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:clampGrid",
      "name": "clampGrid",
      "label": "ƒ clampGrid",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:event-bus.js:clear",
      "name": "clear",
      "label": "ƒ clear",
      "detail": "função detectada · js/event-bus.js",
      "file": "js/event-bus.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:clear",
      "name": "clear",
      "label": "ƒ clear",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:clear",
      "name": "clear",
      "label": "ƒ clear",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:clearActorCaches",
      "name": "clearActorCaches",
      "label": "ƒ clearActorCaches",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:clearBattle",
      "name": "clearBattle",
      "label": "ƒ clearBattle",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:clocks",
      "name": "clocks",
      "label": "ƒ clocks",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:clone",
      "name": "clone",
      "label": "ƒ clone",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:close",
      "name": "close",
      "label": "ƒ close",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:closeAll",
      "name": "closeAll",
      "label": "ƒ closeAll",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:closeTop",
      "name": "closeTop",
      "label": "ƒ closeTop",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:closeVisualOptions",
      "name": "closeVisualOptions",
      "label": "ƒ closeVisualOptions",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:coarse",
      "name": "coarse",
      "label": "ƒ coarse",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:composeNpcFrame",
      "name": "composeNpcFrame",
      "label": "ƒ composeNpcFrame",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:composePlayerFrame",
      "name": "composePlayerFrame",
      "label": "ƒ composePlayerFrame",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:configureHiDPICanvas",
      "name": "configureHiDPICanvas",
      "label": "ƒ configureHiDPICanvas",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:connectionExit",
      "name": "connectionExit",
      "label": "ƒ connectionExit",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:consumePerkMomentum",
      "name": "consumePerkMomentum",
      "label": "ƒ consumePerkMomentum",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:contactShadow",
      "name": "contactShadow",
      "label": "ƒ contactShadow",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:createCanvas",
      "name": "createCanvas",
      "label": "ƒ createCanvas",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:createCanvas",
      "name": "createCanvas",
      "label": "ƒ createCanvas",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:entities.js:createEntitySystem",
      "name": "createEntitySystem",
      "label": "ƒ createEntitySystem",
      "detail": "função detectada · js/entities.js",
      "file": "js/entities.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:inventory.js:createInventory",
      "name": "createInventory",
      "label": "ƒ createInventory",
      "detail": "função detectada · js/inventory.js",
      "file": "js/inventory.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:renderer-layers.js:createLayerRenderer",
      "name": "createLayerRenderer",
      "label": "ƒ createLayerRenderer",
      "detail": "função detectada · js/renderer-layers.js",
      "file": "js/renderer-layers.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:createLocalStorageBackend",
      "name": "createLocalStorageBackend",
      "label": "ƒ createLocalStorageBackend",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:createSaveStorage",
      "name": "createSaveStorage",
      "label": "ƒ createSaveStorage",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:amuletCraftRecipes",
      "name": "CRPG.data.amuletCraftRecipes",
      "label": "📦 CRPG.data.amuletCraftRecipes",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:amuletCraftRecipes",
      "name": "CRPG.data.amuletCraftRecipes",
      "label": "📦 CRPG.data.amuletCraftRecipes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:amuletCraftRecipes",
      "name": "CRPG.data.amuletCraftRecipes",
      "label": "📦 CRPG.data.amuletCraftRecipes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:archeryLevels",
      "name": "CRPG.data.archeryLevels",
      "label": "📦 CRPG.data.archeryLevels",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:archeryLevels",
      "name": "CRPG.data.archeryLevels",
      "label": "📦 CRPG.data.archeryLevels",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:archeryLevels",
      "name": "CRPG.data.archeryLevels",
      "label": "📦 CRPG.data.archeryLevels",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:arrowCraftRecipes",
      "name": "CRPG.data.arrowCraftRecipes",
      "label": "📦 CRPG.data.arrowCraftRecipes",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:arrowCraftRecipes",
      "name": "CRPG.data.arrowCraftRecipes",
      "label": "📦 CRPG.data.arrowCraftRecipes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:arrowCraftRecipes",
      "name": "CRPG.data.arrowCraftRecipes",
      "label": "📦 CRPG.data.arrowCraftRecipes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:barTimes",
      "name": "CRPG.data.barTimes",
      "label": "📦 CRPG.data.barTimes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:bowCraftRecipes",
      "name": "CRPG.data.bowCraftRecipes",
      "label": "📦 CRPG.data.bowCraftRecipes",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:bowCraftRecipes",
      "name": "CRPG.data.bowCraftRecipes",
      "label": "📦 CRPG.data.bowCraftRecipes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:bowCraftRecipes",
      "name": "CRPG.data.bowCraftRecipes",
      "label": "📦 CRPG.data.bowCraftRecipes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:craftingLevels",
      "name": "CRPG.data.craftingLevels",
      "label": "📦 CRPG.data.craftingLevels",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:craftingLevels",
      "name": "CRPG.data.craftingLevels",
      "label": "📦 CRPG.data.craftingLevels",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:craftingLevels",
      "name": "CRPG.data.craftingLevels",
      "label": "📦 CRPG.data.craftingLevels",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:economyCatalog",
      "name": "CRPG.data.economyCatalog",
      "label": "📦 CRPG.data.economyCatalog",
      "detail": "registry de dados · data/economy.js",
      "file": "data/economy.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:enemies",
      "name": "CRPG.data.enemies",
      "label": "📦 CRPG.data.enemies",
      "detail": "registry de dados · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:equipHandRules",
      "name": "CRPG.data.equipHandRules",
      "label": "📦 CRPG.data.equipHandRules",
      "detail": "registry de dados · data/equipment.js",
      "file": "data/equipment.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishingBaits",
      "name": "CRPG.data.fishingBaits",
      "label": "📦 CRPG.data.fishingBaits",
      "detail": "registry de dados · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishingEcosystems",
      "name": "CRPG.data.fishingEcosystems",
      "label": "📦 CRPG.data.fishingEcosystems",
      "detail": "registry de dados · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishingWaters",
      "name": "CRPG.data.fishingWaters",
      "label": "📦 CRPG.data.fishingWaters",
      "detail": "registry de dados · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishingWaters",
      "name": "CRPG.data.fishingWaters",
      "label": "📦 CRPG.data.fishingWaters",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishTiers",
      "name": "CRPG.data.fishTiers",
      "label": "📦 CRPG.data.fishTiers",
      "detail": "registry de dados · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishTiers",
      "name": "CRPG.data.fishTiers",
      "label": "📦 CRPG.data.fishTiers",
      "detail": "registry de dados · data/gathering-requirements.js",
      "file": "data/gathering-requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishTiers",
      "name": "CRPG.data.fishTiers",
      "label": "📦 CRPG.data.fishTiers",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:fishTiers",
      "name": "CRPG.data.fishTiers",
      "label": "📦 CRPG.data.fishTiers",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gatheringRequirements",
      "name": "CRPG.data.gatheringRequirements",
      "label": "📦 CRPG.data.gatheringRequirements",
      "detail": "registry de dados · data/gathering-requirements.js",
      "file": "data/gathering-requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gearCategories",
      "name": "CRPG.data.gearCategories",
      "label": "📦 CRPG.data.gearCategories",
      "detail": "registry de dados · data/equipment.js",
      "file": "data/equipment.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gearStats",
      "name": "CRPG.data.gearStats",
      "label": "📦 CRPG.data.gearStats",
      "detail": "registry de dados · data/equipment.js",
      "file": "data/equipment.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gemCutRecipes",
      "name": "CRPG.data.gemCutRecipes",
      "label": "📦 CRPG.data.gemCutRecipes",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gemCutRecipes",
      "name": "CRPG.data.gemCutRecipes",
      "label": "📦 CRPG.data.gemCutRecipes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:gemCutRecipes",
      "name": "CRPG.data.gemCutRecipes",
      "label": "📦 CRPG.data.gemCutRecipes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:locations",
      "name": "CRPG.data.locations",
      "label": "📦 CRPG.data.locations",
      "detail": "registry de dados · data/locations.js",
      "file": "data/locations.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:locations",
      "name": "CRPG.data.locations",
      "label": "📦 CRPG.data.locations",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:mapCodes",
      "name": "CRPG.data.mapCodes",
      "label": "📦 CRPG.data.mapCodes",
      "detail": "registry de dados · data/map-codes.js",
      "file": "data/map-codes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:mapCodesByArea",
      "name": "CRPG.data.mapCodesByArea",
      "label": "📦 CRPG.data.mapCodesByArea",
      "detail": "registry de dados · data/map-codes.js",
      "file": "data/map-codes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:mapConnections",
      "name": "CRPG.data.mapConnections",
      "label": "📦 CRPG.data.mapConnections",
      "detail": "registry de dados · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:masteryProfiles",
      "name": "CRPG.data.masteryProfiles",
      "label": "📦 CRPG.data.masteryProfiles",
      "detail": "registry de dados · data/mastery.js",
      "file": "data/mastery.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:mineableMaterials",
      "name": "CRPG.data.mineableMaterials",
      "label": "📦 CRPG.data.mineableMaterials",
      "detail": "registry de dados · data/tiers.js",
      "file": "data/tiers.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:npcs",
      "name": "CRPG.data.npcs",
      "label": "📦 CRPG.data.npcs",
      "detail": "registry de dados · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:overworldExpansionPlanV00146",
      "name": "CRPG.data.overworldExpansionPlanV00146",
      "label": "📦 CRPG.data.overworldExpansionPlanV00146",
      "detail": "registry de dados · data/overworld-expansion-plan-v00146.js",
      "file": "data/overworld-expansion-plan-v00146.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:overworldReviewV00151",
      "name": "CRPG.data.overworldReviewV00151",
      "label": "📦 CRPG.data.overworldReviewV00151",
      "detail": "registry de dados · data/world.js",
      "file": "data/world.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:productionChains",
      "name": "CRPG.data.productionChains",
      "label": "📦 CRPG.data.productionChains",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:professionalContracts",
      "name": "CRPG.data.professionalContracts",
      "label": "📦 CRPG.data.professionalContracts",
      "detail": "registry de dados · data/professional-contracts.js",
      "file": "data/professional-contracts.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:professionQuestLines",
      "name": "CRPG.data.professionQuestLines",
      "label": "📦 CRPG.data.professionQuestLines",
      "detail": "registry de dados · data/profession-quests.js",
      "file": "data/profession-quests.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:professionQuestStages",
      "name": "CRPG.data.professionQuestStages",
      "label": "📦 CRPG.data.professionQuestStages",
      "detail": "registry de dados · data/profession-quests.js",
      "file": "data/profession-quests.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:progressionBands",
      "name": "CRPG.data.progressionBands",
      "label": "📦 CRPG.data.progressionBands",
      "detail": "registry de dados · data/progression-balance.js",
      "file": "data/progression-balance.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:questLogMeta",
      "name": "CRPG.data.questLogMeta",
      "label": "📦 CRPG.data.questLogMeta",
      "detail": "registry de dados · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:questSkillChecks",
      "name": "CRPG.data.questSkillChecks",
      "label": "📦 CRPG.data.questSkillChecks",
      "detail": "registry de dados · data/quest-skill-checks.js",
      "file": "data/quest-skill-checks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:races",
      "name": "CRPG.data.races",
      "label": "📦 CRPG.data.races",
      "detail": "registry de dados · data/world.js",
      "file": "data/world.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:regions",
      "name": "CRPG.data.regions",
      "label": "📦 CRPG.data.regions",
      "detail": "registry de dados · data/world.js",
      "file": "data/world.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:resourceNodes",
      "name": "CRPG.data.resourceNodes",
      "label": "📦 CRPG.data.resourceNodes",
      "detail": "registry de dados · data/content.js",
      "file": "data/content.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:resourceNodes",
      "name": "CRPG.data.resourceNodes",
      "label": "📦 CRPG.data.resourceNodes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:resourceTimes",
      "name": "CRPG.data.resourceTimes",
      "label": "📦 CRPG.data.resourceTimes",
      "detail": "registry de dados · data/resources.js",
      "file": "data/resources.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:screenTierRules",
      "name": "CRPG.data.screenTierRules",
      "label": "📦 CRPG.data.screenTierRules",
      "detail": "registry de dados · data/world.js",
      "file": "data/world.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:skillEndgameContent",
      "name": "CRPG.data.skillEndgameContent",
      "label": "📦 CRPG.data.skillEndgameContent",
      "detail": "registry de dados · data/skill-endgame.js",
      "file": "data/skill-endgame.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:skillPerks2",
      "name": "CRPG.data.skillPerks2",
      "label": "📦 CRPG.data.skillPerks2",
      "detail": "registry de dados · data/perks.js",
      "file": "data/perks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:skills",
      "name": "CRPG.data.skills",
      "label": "📦 CRPG.data.skills",
      "detail": "registry de dados · data/skill-endgame.js",
      "file": "data/skill-endgame.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:skills",
      "name": "CRPG.data.skills",
      "label": "📦 CRPG.data.skills",
      "detail": "registry de dados · data/skills.js",
      "file": "data/skills.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:smithItemRecipes",
      "name": "CRPG.data.smithItemRecipes",
      "label": "📦 CRPG.data.smithItemRecipes",
      "detail": "registry de dados · data/equipment.js",
      "file": "data/equipment.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:smithXp",
      "name": "CRPG.data.smithXp",
      "label": "📦 CRPG.data.smithXp",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:specialBarRecipes",
      "name": "CRPG.data.specialBarRecipes",
      "label": "📦 CRPG.data.specialBarRecipes",
      "detail": "registry de dados · data/recipes.js",
      "file": "data/recipes.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:tiers",
      "name": "CRPG.data.tiers",
      "label": "📦 CRPG.data.tiers",
      "detail": "registry de dados · data/gathering-requirements.js",
      "file": "data/gathering-requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:tiers",
      "name": "CRPG.data.tiers",
      "label": "📦 CRPG.data.tiers",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:tiers",
      "name": "CRPG.data.tiers",
      "label": "📦 CRPG.data.tiers",
      "detail": "registry de dados · data/tiers.js",
      "file": "data/tiers.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:tiers",
      "name": "CRPG.data.tiers",
      "label": "📦 CRPG.data.tiers",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:treeTypes",
      "name": "CRPG.data.treeTypes",
      "label": "📦 CRPG.data.treeTypes",
      "detail": "registry de dados · data/gathering-requirements.js",
      "file": "data/gathering-requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:treeTypes",
      "name": "CRPG.data.treeTypes",
      "label": "📦 CRPG.data.treeTypes",
      "detail": "registry de dados · data/production-chains.js",
      "file": "data/production-chains.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:treeTypes",
      "name": "CRPG.data.treeTypes",
      "label": "📦 CRPG.data.treeTypes",
      "detail": "registry de dados · data/resources.js",
      "file": "data/resources.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:treeTypes",
      "name": "CRPG.data.treeTypes",
      "label": "📦 CRPG.data.treeTypes",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:unlocks",
      "name": "CRPG.data.unlocks",
      "label": "📦 CRPG.data.unlocks",
      "detail": "registry de dados · data/unlocks.js",
      "file": "data/unlocks.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:waterTiers",
      "name": "CRPG.data.waterTiers",
      "label": "📦 CRPG.data.waterTiers",
      "detail": "registry de dados · data/fish.js",
      "file": "data/fish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:worldMapV00156",
      "name": "CRPG.data.worldMapV00156",
      "label": "📦 CRPG.data.worldMapV00156",
      "detail": "registry de dados · data/world-map-v00156.js",
      "file": "data/world-map-v00156.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:worldMapV00157",
      "name": "CRPG.data.worldMapV00157",
      "label": "📦 CRPG.data.worldMapV00157",
      "detail": "registry de dados · data/world-map-v00157.js",
      "file": "data/world-map-v00157.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:worldMapV00163",
      "name": "CRPG.data.worldMapV00163",
      "label": "📦 CRPG.data.worldMapV00163",
      "detail": "registry de dados · data/world-map-v00163.js",
      "file": "data/world-map-v00163.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "data:worldProjects",
      "name": "CRPG.data.worldProjects",
      "label": "📦 CRPG.data.worldProjects",
      "detail": "registry de dados · data/world-projects.js",
      "file": "data/world-projects.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:customPalette",
      "name": "customPalette",
      "label": "ƒ customPalette",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:death",
      "name": "death",
      "label": "ƒ death",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:death",
      "name": "death",
      "label": "ƒ death",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:defaultAppearance",
      "name": "defaultAppearance",
      "label": "ƒ defaultAppearance",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:defend",
      "name": "defend",
      "label": "ƒ defend",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-visuals.js:density",
      "name": "density",
      "label": "ƒ density",
      "detail": "função detectada · js/terrain-visuals.js",
      "file": "js/terrain-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:depth",
      "name": "depth",
      "label": "ƒ depth",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-visuals.js:detail",
      "name": "detail",
      "label": "ƒ detail",
      "detail": "função detectada · js/terrain-visuals.js",
      "file": "js/terrain-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:interaction-visuals.js:devicePrompt",
      "name": "devicePrompt",
      "label": "ƒ devicePrompt",
      "detail": "função detectada · js/interaction-visuals.js",
      "file": "js/interaction-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:dispatch",
      "name": "dispatch",
      "label": "ƒ dispatch",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:domCanvas",
      "name": "domCanvas",
      "label": "ƒ domCanvas",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:dot",
      "name": "dot",
      "label": "ƒ dot",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:doubleYieldChance",
      "name": "doubleYieldChance",
      "label": "ƒ doubleYieldChance",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:doubleYieldFeedback",
      "name": "doubleYieldFeedback",
      "label": "ƒ doubleYieldFeedback",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:gathering-vfx.js:draw",
      "name": "draw",
      "label": "ƒ draw",
      "detail": "função detectada · js/gathering-vfx.js",
      "file": "js/gathering-vfx.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:interaction-visuals.js:draw",
      "name": "draw",
      "label": "ƒ draw",
      "detail": "função detectada · js/interaction-visuals.js",
      "file": "js/interaction-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:lighting.js:drawAmbient",
      "name": "drawAmbient",
      "label": "ƒ drawAmbient",
      "detail": "função detectada · js/lighting.js",
      "file": "js/lighting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawAmuletBase",
      "name": "drawAmuletBase",
      "label": "ƒ drawAmuletBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:drawAnimated",
      "name": "drawAnimated",
      "label": "ƒ drawAnimated",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawArenaGround",
      "name": "drawArenaGround",
      "label": "ƒ drawArenaGround",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawArmorBase",
      "name": "drawArmorBase",
      "label": "ƒ drawArmorBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:drawAt",
      "name": "drawAt",
      "label": "ƒ drawAt",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:drawAttackLayers",
      "name": "drawAttackLayers",
      "label": "ƒ drawAttackLayers",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawAxeBase",
      "name": "drawAxeBase",
      "label": "ƒ drawAxeBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawBase",
      "name": "drawBase",
      "label": "ƒ drawBase",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawBatEnemy",
      "name": "drawBatEnemy",
      "label": "ƒ drawBatEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:drawBattle",
      "name": "drawBattle",
      "label": "ƒ drawBattle",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:drawBg",
      "name": "drawBg",
      "label": "ƒ drawBg",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawBg",
      "name": "drawBg",
      "label": "ƒ drawBg",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawBootsBase",
      "name": "drawBootsBase",
      "label": "ƒ drawBootsBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:shadow-system.js:drawBox",
      "name": "drawBox",
      "label": "ƒ drawBox",
      "detail": "função detectada · js/shadow-system.js",
      "file": "js/shadow-system.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:drawBushAccent",
      "name": "drawBushAccent",
      "label": "ƒ drawBushAccent",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:drawCanvas",
      "name": "drawCanvas",
      "label": "ƒ drawCanvas",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawCapybaraEnemy",
      "name": "drawCapybaraEnemy",
      "label": "ƒ drawCapybaraEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawCave",
      "name": "drawCave",
      "label": "ƒ drawCave",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawChickenEnemy",
      "name": "drawChickenEnemy",
      "label": "ƒ drawChickenEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:interaction-visuals.js:drawCorners",
      "name": "drawCorners",
      "label": "ƒ drawCorners",
      "detail": "função detectada · js/interaction-visuals.js",
      "file": "js/interaction-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawDarkForest",
      "name": "drawDarkForest",
      "label": "ƒ drawDarkForest",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:drawDecorAccent",
      "name": "drawDecorAccent",
      "label": "ƒ drawDecorAccent",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawDragonEnemy",
      "name": "drawDragonEnemy",
      "label": "ƒ drawDragonEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawEnemy",
      "name": "drawEnemy",
      "label": "ƒ drawEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawEnemyRaw",
      "name": "drawEnemyRaw",
      "label": "ƒ drawEnemyRaw",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:shadow-system.js:drawEntity",
      "name": "drawEntity",
      "label": "ƒ drawEntity",
      "detail": "função detectada · js/shadow-system.js",
      "file": "js/shadow-system.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawEntrance007",
      "name": "drawEntrance007",
      "label": "ƒ drawEntrance007",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:drawFighter",
      "name": "drawFighter",
      "label": "ƒ drawFighter",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:drawFish",
      "name": "drawFish",
      "label": "ƒ drawFish",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawFrontHair",
      "name": "drawFrontHair",
      "label": "ƒ drawFrontHair",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawFx",
      "name": "drawFx",
      "label": "ƒ drawFx",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:drawGem",
      "name": "drawGem",
      "label": "ƒ drawGem",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawGlovesBase",
      "name": "drawGlovesBase",
      "label": "ƒ drawGlovesBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawGoatEnemy",
      "name": "drawGoatEnemy",
      "label": "ƒ drawGoatEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawHelmetBase",
      "name": "drawHelmetBase",
      "label": "ƒ drawHelmetBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:lighting.js:drawLocalLight",
      "name": "drawLocalLight",
      "label": "ƒ drawLocalLight",
      "detail": "função detectada · js/lighting.js",
      "file": "js/lighting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:drawLogical",
      "name": "drawLogical",
      "label": "ƒ drawLogical",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawMushroomForest",
      "name": "drawMushroomForest",
      "label": "ƒ drawMushroomForest",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawNpc",
      "name": "drawNpc",
      "label": "ƒ drawNpc",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawNpcRaw",
      "name": "drawNpcRaw",
      "label": "ƒ drawNpcRaw",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:drawOne",
      "name": "drawOne",
      "label": "ƒ drawOne",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:drawParticles",
      "name": "drawParticles",
      "label": "ƒ drawParticles",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawPickaxeBase",
      "name": "drawPickaxeBase",
      "label": "ƒ drawPickaxeBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawPixelBurst",
      "name": "drawPixelBurst",
      "label": "ƒ drawPixelBurst",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawPlayer",
      "name": "drawPlayer",
      "label": "ƒ drawPlayer",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawPlayerPortrait",
      "name": "drawPlayerPortrait",
      "label": "ƒ drawPlayerPortrait",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawPlayerRaw",
      "name": "drawPlayerRaw",
      "label": "ƒ drawPlayerRaw",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawRaceEye",
      "name": "drawRaceEye",
      "label": "ƒ drawRaceEye",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawRatEnemy",
      "name": "drawRatEnemy",
      "label": "ƒ drawRatEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawRegionalBridge",
      "name": "drawRegionalBridge",
      "label": "ƒ drawRegionalBridge",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:drawRoof",
      "name": "drawRoof",
      "label": "ƒ drawRoof",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawShieldBase",
      "name": "drawShieldBase",
      "label": "ƒ drawShieldBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:drawSilhouette",
      "name": "drawSilhouette",
      "label": "ƒ drawSilhouette",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawSlimeEnemy",
      "name": "drawSlimeEnemy",
      "label": "ƒ drawSlimeEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawSpiderEnemy",
      "name": "drawSpiderEnemy",
      "label": "ƒ drawSpiderEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawSpiderLair",
      "name": "drawSpiderLair",
      "label": "ƒ drawSpiderLair",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawStaging",
      "name": "drawStaging",
      "label": "ƒ drawStaging",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawStatusMarks",
      "name": "drawStatusMarks",
      "label": "ƒ drawStatusMarks",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawSwordBase",
      "name": "drawSwordBase",
      "label": "ƒ drawSwordBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:drawTelegraph",
      "name": "drawTelegraph",
      "label": "ƒ drawTelegraph",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawTierFinish",
      "name": "drawTierFinish",
      "label": "ƒ drawTierFinish",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:drawTreeAccent",
      "name": "drawTreeAccent",
      "label": "ƒ drawTreeAccent",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawTurnFocus",
      "name": "drawTurnFocus",
      "label": "ƒ drawTurnFocus",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawVillage005",
      "name": "drawVillage005",
      "label": "ƒ drawVillage005",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:drawVillage006",
      "name": "drawVillage006",
      "label": "ƒ drawVillage006",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:drawWolfEnemy",
      "name": "drawWolfEnemy",
      "label": "ƒ drawWolfEnemy",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:drawWorld",
      "name": "drawWorld",
      "label": "ƒ drawWorld",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:edgeMask",
      "name": "edgeMask",
      "label": "ƒ edgeMask",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:effectiveReducedMotion",
      "name": "effectiveReducedMotion",
      "label": "ƒ effectiveReducedMotion",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:event-bus.js:emit",
      "name": "emit",
      "label": "ƒ emit",
      "detail": "função detectada · js/event-bus.js",
      "file": "js/event-bus.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:gathering-vfx.js:emit",
      "name": "emit",
      "label": "ƒ emit",
      "detail": "função detectada · js/gathering-vfx.js",
      "file": "js/gathering-vfx.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:emitBattle",
      "name": "emitBattle",
      "label": "ƒ emitBattle",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:emitWorld",
      "name": "emitWorld",
      "label": "ƒ emitWorld",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:enemyCacheKey",
      "name": "enemyCacheKey",
      "label": "ƒ enemyCacheKey",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:enemyEyeColor",
      "name": "enemyEyeColor",
      "label": "ƒ enemyEyeColor",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:enemyPixelEye",
      "name": "enemyPixelEye",
      "label": "ƒ enemyPixelEye",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:enemyShadow",
      "name": "enemyShadow",
      "label": "ƒ enemyShadow",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:enqueue",
      "name": "enqueue",
      "label": "ƒ enqueue",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:ensureHost",
      "name": "ensureHost",
      "label": "ƒ ensureHost",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:entries",
      "name": "entries",
      "label": "ƒ entries",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:equipmentCompareHtml",
      "name": "equipmentCompareHtml",
      "label": "ƒ equipmentCompareHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:equipmentStatVector",
      "name": "equipmentStatVector",
      "label": "ƒ equipmentStatVector",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:esc",
      "name": "esc",
      "label": "ƒ esc",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:evaluate",
      "name": "evaluate",
      "label": "ƒ evaluate",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:evaluateOne",
      "name": "evaluateOne",
      "label": "ƒ evaluateOne",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:exampleLayout",
      "name": "exampleLayout",
      "label": "ƒ exampleLayout",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:expandLegacyMap",
      "name": "expandLegacyMap",
      "label": "ƒ expandLegacyMap",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:exportJson",
      "name": "exportJson",
      "label": "ƒ exportJson",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:exportObject",
      "name": "exportObject",
      "label": "ƒ exportObject",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:fishingRodRank",
      "name": "fishingRodRank",
      "label": "ƒ fishingRodRank",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:fixedScreenViewport",
      "name": "fixedScreenViewport",
      "label": "ƒ fixedScreenViewport",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:focusAt",
      "name": "focusAt",
      "label": "ƒ focusAt",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:focusState",
      "name": "focusState",
      "label": "ƒ focusState",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:frame",
      "name": "frame",
      "label": "ƒ frame",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:frame",
      "name": "frame",
      "label": "ƒ frame",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:frame",
      "name": "frame",
      "label": "ƒ frame",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:frameCanvas",
      "name": "frameCanvas",
      "label": "ƒ frameCanvas",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:fsElement",
      "name": "fsElement",
      "label": "ƒ fsElement",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gatheringAccess",
      "name": "gatheringAccess",
      "label": "ƒ gatheringAccess",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gatheringDuration",
      "name": "gatheringDuration",
      "label": "ƒ gatheringDuration",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gatheringXp",
      "name": "gatheringXp",
      "label": "ƒ gatheringXp",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearAttack",
      "name": "gearAttack",
      "label": "ƒ gearAttack",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearColor",
      "name": "gearColor",
      "label": "ƒ gearColor",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearDefense",
      "name": "gearDefense",
      "label": "ƒ gearDefense",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearInfo",
      "name": "gearInfo",
      "label": "ƒ gearInfo",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:gearLayer",
      "name": "gearLayer",
      "label": "ƒ gearLayer",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearRank",
      "name": "gearRank",
      "label": "ƒ gearRank",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearType",
      "name": "gearType",
      "label": "ƒ gearType",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:gearValue",
      "name": "gearValue",
      "label": "ƒ gearValue",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:gemKey",
      "name": "gemKey",
      "label": "ƒ gemKey",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:gemPal",
      "name": "gemPal",
      "label": "ƒ gemPal",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:get",
      "name": "get",
      "label": "ƒ get",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:getOrCreate",
      "name": "getOrCreate",
      "label": "ƒ getOrCreate",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:getRegion",
      "name": "getRegion",
      "label": "ƒ getRegion",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:grantPerkMomentum",
      "name": "grantPerkMomentum",
      "label": "ƒ grantPerkMomentum",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-autotile.js:has",
      "name": "has",
      "label": "ƒ has",
      "detail": "função detectada · js/terrain-autotile.js",
      "file": "js/terrain-autotile.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:hash",
      "name": "hash",
      "label": "ƒ hash",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-visuals.js:hash",
      "name": "hash",
      "label": "ƒ hash",
      "detail": "função detectada · js/terrain-visuals.js",
      "file": "js/terrain-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:hash",
      "name": "hash",
      "label": "ƒ hash",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:hash",
      "name": "hash",
      "label": "ƒ hash",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:hashString",
      "name": "hashString",
      "label": "ƒ hashString",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:hashText",
      "name": "hashText",
      "label": "ƒ hashText",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:heal",
      "name": "heal",
      "label": "ƒ heal",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:hexToHsl",
      "name": "hexToHsl",
      "label": "ƒ hexToHsl",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:hidePanelHoverTooltip",
      "name": "hidePanelHoverTooltip",
      "label": "ƒ hidePanelHoverTooltip",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:hslToHex",
      "name": "hslToHex",
      "label": "ƒ hslToHex",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:html",
      "name": "html",
      "label": "ƒ html",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:hydrate",
      "name": "hydrate",
      "label": "ƒ hydrate",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:hydrateItemArt",
      "name": "hydrateItemArt",
      "label": "ƒ hydrateItemArt",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:hydrateStatic",
      "name": "hydrateStatic",
      "label": "ƒ hydrateStatic",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:impact",
      "name": "impact",
      "label": "ƒ impact",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:impact",
      "name": "impact",
      "label": "ƒ impact",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:impactKick",
      "name": "impactKick",
      "label": "ƒ impactKick",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:impactOffset",
      "name": "impactOffset",
      "label": "ƒ impactOffset",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:importJson",
      "name": "importJson",
      "label": "ƒ importJson",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:init",
      "name": "init",
      "label": "ƒ init",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:init",
      "name": "init",
      "label": "ƒ init",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:isHeld",
      "name": "isHeld",
      "label": "ƒ isHeld",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:isKnown",
      "name": "isKnown",
      "label": "ƒ isKnown",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:isOpen",
      "name": "isOpen",
      "label": "ƒ isOpen",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:itemArtHtml",
      "name": "itemArtHtml",
      "label": "ƒ itemArtHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:itemFlavor",
      "name": "itemFlavor",
      "label": "ƒ itemFlavor",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:itemFromHash",
      "name": "itemFromHash",
      "label": "ƒ itemFromHash",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:itemLogArt",
      "name": "itemLogArt",
      "label": "ƒ itemLogArt",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:itemName",
      "name": "itemName",
      "label": "ƒ itemName",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:itemRarity",
      "name": "itemRarity",
      "label": "ƒ itemRarity",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:itemStateBadgesHtml",
      "name": "itemStateBadgesHtml",
      "label": "ƒ itemStateBadgesHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:key",
      "name": "key",
      "label": "ƒ key",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:laneFor",
      "name": "laneFor",
      "label": "ƒ laneFor",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:legacySpan",
      "name": "legacySpan",
      "label": "ƒ legacySpan",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:legacySpanY",
      "name": "legacySpanY",
      "label": "ƒ legacySpanY",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:line",
      "name": "line",
      "label": "ƒ line",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:linePx",
      "name": "linePx",
      "label": "ƒ linePx",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:list",
      "name": "list",
      "label": "ƒ list",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:loadAccessibility",
      "name": "loadAccessibility",
      "label": "ƒ loadAccessibility",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:magic",
      "name": "magic",
      "label": "ƒ magic",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:magic",
      "name": "magic",
      "label": "ƒ magic",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:makeCanvas",
      "name": "makeCanvas",
      "label": "ƒ makeCanvas",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:markItemSeen",
      "name": "markItemSeen",
      "label": "ƒ markItemSeen",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-autotile.js:maskAt",
      "name": "maskAt",
      "label": "ƒ maskAt",
      "detail": "função detectada · js/terrain-autotile.js",
      "file": "js/terrain-autotile.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:material",
      "name": "material",
      "label": "ƒ material",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:measure",
      "name": "measure",
      "label": "ƒ measure",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:mergeOrPush",
      "name": "mergeOrPush",
      "label": "ƒ mergeOrPush",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:meta",
      "name": "meta",
      "label": "ƒ meta",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:neighbors",
      "name": "neighbors",
      "label": "ƒ neighbors",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:normalize",
      "name": "normalize",
      "label": "ƒ normalize",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:noteArea",
      "name": "noteArea",
      "label": "ƒ noteArea",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:now",
      "name": "now",
      "label": "ƒ now",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:now",
      "name": "now",
      "label": "ƒ now",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:now",
      "name": "now",
      "label": "ƒ now",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:now",
      "name": "now",
      "label": "ƒ now",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:npcCacheKey",
      "name": "npcCacheKey",
      "label": "ƒ npcCacheKey",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:npcHat",
      "name": "npcHat",
      "label": "ƒ npcHat",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:npcRaceDetails",
      "name": "npcRaceDetails",
      "label": "ƒ npcRaceDetails",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:npcRoleDetails",
      "name": "npcRoleDetails",
      "label": "ƒ npcRoleDetails",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:event-bus.js:off",
      "name": "off",
      "label": "ƒ off",
      "detail": "função detectada · js/event-bus.js",
      "file": "js/event-bus.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:offscreenCanvas",
      "name": "offscreenCanvas",
      "label": "ƒ offscreenCanvas",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:onAction",
      "name": "onAction",
      "label": "ƒ onAction",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:event-bus.js:onAny",
      "name": "onAny",
      "label": "ƒ onAny",
      "detail": "função detectada · js/event-bus.js",
      "file": "js/event-bus.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:event-bus.js:once",
      "name": "once",
      "label": "ƒ once",
      "detail": "função detectada · js/event-bus.js",
      "file": "js/event-bus.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:open",
      "name": "open",
      "label": "ƒ open",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:openVisualOptions",
      "name": "openVisualOptions",
      "label": "ƒ openVisualOptions",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:outlineRect",
      "name": "outlineRect",
      "label": "ƒ outlineRect",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:pal",
      "name": "pal",
      "label": "ƒ pal",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:paletteKey",
      "name": "paletteKey",
      "label": "ƒ paletteKey",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:parseImport",
      "name": "parseImport",
      "label": "ƒ parseImport",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:particleScale",
      "name": "particleScale",
      "label": "ƒ particleScale",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:particleScale",
      "name": "particleScale",
      "label": "ƒ particleScale",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:particleScale",
      "name": "particleScale",
      "label": "ƒ particleScale",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:perfectActionChance",
      "name": "perfectActionChance",
      "label": "ƒ perfectActionChance",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:perfectActionFeedback",
      "name": "perfectActionFeedback",
      "label": "ƒ perfectActionFeedback",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:vegetation-visuals.js:phaseFor",
      "name": "phaseFor",
      "label": "ƒ phaseFor",
      "detail": "função detectada · js/vegetation-visuals.js",
      "file": "js/vegetation-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:physical",
      "name": "physical",
      "label": "ƒ physical",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:physical",
      "name": "physical",
      "label": "ƒ physical",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:lighting.js:pixelBand",
      "name": "pixelBand",
      "label": "ƒ pixelBand",
      "detail": "função detectada · js/lighting.js",
      "file": "js/lighting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:pixelizeItemEmojiHtml",
      "name": "pixelizeItemEmojiHtml",
      "label": "ƒ pixelizeItemEmojiHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:pixelLeg",
      "name": "pixelLeg",
      "label": "ƒ pixelLeg",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:pixelRing",
      "name": "pixelRing",
      "label": "ƒ pixelRing",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:plan",
      "name": "plan",
      "label": "ƒ plan",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:playerBase",
      "name": "playerBase",
      "label": "ƒ playerBase",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:playerCacheKey",
      "name": "playerCacheKey",
      "label": "ƒ playerCacheKey",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:poly",
      "name": "poly",
      "label": "ƒ poly",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:portrait",
      "name": "portrait",
      "label": "ƒ portrait",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:positionPanelHoverTooltip",
      "name": "positionPanelHoverTooltip",
      "label": "ƒ positionPanelHoverTooltip",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:presentationScale",
      "name": "presentationScale",
      "label": "ƒ presentationScale",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:press",
      "name": "press",
      "label": "ƒ press",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:profile",
      "name": "profile",
      "label": "ƒ profile",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-identity.js:profile",
      "name": "profile",
      "label": "ƒ profile",
      "detail": "função detectada · js/region-identity.js",
      "file": "js/region-identity.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:profileFor",
      "name": "profileFor",
      "label": "ƒ profileFor",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:lighting.js:profileName",
      "name": "profileName",
      "label": "ƒ profileName",
      "detail": "função detectada · js/lighting.js",
      "file": "js/lighting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:quantizedActionFrame",
      "name": "quantizedActionFrame",
      "label": "ƒ quantizedActionFrame",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:quantizedWalkFrame",
      "name": "quantizedWalkFrame",
      "label": "ƒ quantizedWalkFrame",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:questDone",
      "name": "questDone",
      "label": "ƒ questDone",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:ranged",
      "name": "ranged",
      "label": "ƒ ranged",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:ranged",
      "name": "ranged",
      "label": "ƒ ranged",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rangedAttackBonus",
      "name": "rangedAttackBonus",
      "label": "ƒ rangedAttackBonus",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rarityBadgeHtml",
      "name": "rarityBadgeHtml",
      "label": "ƒ rarityBadgeHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rarityClass",
      "name": "rarityClass",
      "label": "ƒ rarityClass",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rarityFromRank",
      "name": "rarityFromRank",
      "label": "ƒ rarityFromRank",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rarityItemHtml",
      "name": "rarityItemHtml",
      "label": "ƒ rarityItemHtml",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:rarityKey",
      "name": "rarityKey",
      "label": "ƒ rarityKey",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rarityMeta",
      "name": "rarityMeta",
      "label": "ƒ rarityMeta",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:raw",
      "name": "raw",
      "label": "ƒ raw",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:read",
      "name": "read",
      "label": "ƒ read",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:rect",
      "name": "rect",
      "label": "ƒ rect",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:reduced",
      "name": "reduced",
      "label": "ƒ reduced",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:reducedMotion",
      "name": "reducedMotion",
      "label": "ƒ reducedMotion",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:regionKey",
      "name": "regionKey",
      "label": "ƒ regionKey",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:regionTheme",
      "name": "regionTheme",
      "label": "ƒ regionTheme",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:registerOverlay",
      "name": "registerOverlay",
      "label": "ƒ registerOverlay",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:release",
      "name": "release",
      "label": "ƒ release",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:remove",
      "name": "remove",
      "label": "ƒ remove",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:lighting.js:render",
      "name": "render",
      "label": "ƒ render",
      "detail": "função detectada · js/lighting.js",
      "file": "js/lighting.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:render",
      "name": "render",
      "label": "ƒ render",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:render",
      "name": "render",
      "label": "ƒ render",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:renderExample",
      "name": "renderExample",
      "label": "ƒ renderExample",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:renderFacade",
      "name": "renderFacade",
      "label": "ƒ renderFacade",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:renderInteriorStory",
      "name": "renderInteriorStory",
      "label": "ƒ renderInteriorStory",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:renderInteriorStoryV3",
      "name": "renderInteriorStoryV3",
      "label": "ƒ renderInteriorStoryV3",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:renderTransition",
      "name": "renderTransition",
      "label": "ƒ renderTransition",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:gathering-vfx.js:reset",
      "name": "reset",
      "label": "ƒ reset",
      "detail": "função detectada · js/gathering-vfx.js",
      "file": "js/gathering-vfx.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:reset",
      "name": "reset",
      "label": "ƒ reset",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:resetAnim",
      "name": "resetAnim",
      "label": "ƒ resetAnim",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:resetArea",
      "name": "resetArea",
      "label": "ƒ resetArea",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:resetVisualOptions",
      "name": "resetVisualOptions",
      "label": "ƒ resetVisualOptions",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:resourceRank",
      "name": "resourceRank",
      "label": "ƒ resourceRank",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:restoreBackup",
      "name": "restoreBackup",
      "label": "ƒ restoreBackup",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:roleSign",
      "name": "roleSign",
      "label": "ƒ roleSign",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rollDoubleYield",
      "name": "rollDoubleYield",
      "label": "ƒ rollDoubleYield",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:rollPerfectAction",
      "name": "rollPerfectAction",
      "label": "ƒ rollPerfectAction",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:rows",
      "name": "rows",
      "label": "ƒ rows",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:reward-presentation.js:run",
      "name": "run",
      "label": "ƒ run",
      "detail": "função detectada · js/reward-presentation.js",
      "file": "js/reward-presentation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:safeJsonParse",
      "name": "safeJsonParse",
      "label": "ƒ safeJsonParse",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:save",
      "name": "save",
      "label": "ƒ save",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:saveVisualOptions",
      "name": "saveVisualOptions",
      "label": "ƒ saveVisualOptions",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:scaleV00164Point",
      "name": "scaleV00164Point",
      "label": "ƒ scaleV00164Point",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:sceneSeed",
      "name": "sceneSeed",
      "label": "ƒ sceneSeed",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:scriptedCameraFrame",
      "name": "scriptedCameraFrame",
      "label": "ƒ scriptedCameraFrame",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:seed",
      "name": "seed",
      "label": "ƒ seed",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:shadow",
      "name": "shadow",
      "label": "ƒ shadow",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:shiftHex",
      "name": "shiftHex",
      "label": "ƒ shiftHex",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:showPanelHoverTooltip",
      "name": "showPanelHoverTooltip",
      "label": "ƒ showPanelHoverTooltip",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:sidePos",
      "name": "sidePos",
      "label": "ƒ sidePos",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:sidePos",
      "name": "sidePos",
      "label": "ƒ sidePos",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-autotile.js:signature",
      "name": "signature",
      "label": "ƒ signature",
      "detail": "função detectada · js/terrain-autotile.js",
      "file": "js/terrain-autotile.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:skillName",
      "name": "skillName",
      "label": "ƒ skillName",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:requirements.js:SKILLS",
      "name": "SKILLS",
      "label": "ƒ SKILLS",
      "detail": "função detectada · js/requirements.js",
      "file": "js/requirements.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:skinPalette",
      "name": "skinPalette",
      "label": "ƒ skinPalette",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:slot",
      "name": "slot",
      "label": "ƒ slot",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:smithLevelFor",
      "name": "smithLevelFor",
      "label": "ƒ smithLevelFor",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:camera-polish.js:smooth",
      "name": "smooth",
      "label": "ƒ smooth",
      "detail": "função detectada · js/camera-polish.js",
      "file": "js/camera-polish.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:spawn",
      "name": "spawn",
      "label": "ƒ spawn",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:stableAppearanceKey",
      "name": "stableAppearanceKey",
      "label": "ƒ stableAppearanceKey",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:stableEquipmentKey",
      "name": "stableEquipmentKey",
      "label": "ƒ stableEquipmentKey",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:state",
      "name": "state",
      "label": "ƒ state",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:water-visuals.js:staticTone",
      "name": "staticTone",
      "label": "ƒ staticTone",
      "detail": "função detectada · js/water-visuals.js",
      "file": "js/water-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:render-cache.js:stats",
      "name": "stats",
      "label": "ƒ stats",
      "detail": "função detectada · js/render-cache.js",
      "file": "js/render-cache.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:status",
      "name": "status",
      "label": "ƒ status",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:steppedBox",
      "name": "steppedBox",
      "label": "ƒ steppedBox",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:stop",
      "name": "stop",
      "label": "ƒ stop",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:stop",
      "name": "stop",
      "label": "ƒ stop",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:floating-text.js:style",
      "name": "style",
      "label": "ƒ style",
      "detail": "função detectada · js/floating-text.js",
      "file": "js/floating-text.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-props.js:style",
      "name": "style",
      "label": "ƒ style",
      "detail": "função detectada · js/region-props.js",
      "file": "js/region-props.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:surfaceFamily",
      "name": "surfaceFamily",
      "label": "ƒ surfaceFamily",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:syncAccessibilityForm",
      "name": "syncAccessibilityForm",
      "label": "ƒ syncAccessibilityForm",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:syncFullscreen",
      "name": "syncFullscreen",
      "label": "ƒ syncFullscreen",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:syncOrientationHint",
      "name": "syncOrientationHint",
      "label": "ƒ syncOrientationHint",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:systemReducedMotion",
      "name": "systemReducedMotion",
      "label": "ƒ systemReducedMotion",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:telegraph",
      "name": "telegraph",
      "label": "ƒ telegraph",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:telegraph",
      "name": "telegraph",
      "label": "ƒ telegraph",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:world-decor.js:themeFor",
      "name": "themeFor",
      "label": "ƒ themeFor",
      "detail": "função detectada · js/world-decor.js",
      "file": "js/world-decor.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:item-icons.js:tierAccent",
      "name": "tierAccent",
      "label": "ƒ tierAccent",
      "detail": "função detectada · js/item-icons.js",
      "file": "js/item-icons.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:timestamp",
      "name": "timestamp",
      "label": "ƒ timestamp",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:region-identity.js:tint",
      "name": "tint",
      "label": "ƒ tint",
      "detail": "função detectada · js/region-identity.js",
      "file": "js/region-identity.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ui.js:toggle",
      "name": "toggle",
      "label": "ƒ toggle",
      "detail": "função detectada · js/ui.js",
      "file": "js/ui.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:pwa.js:toggleFullscreen",
      "name": "toggleFullscreen",
      "label": "ƒ toggleFullscreen",
      "detail": "função detectada · js/pwa.js",
      "file": "js/pwa.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:toolEfficiency",
      "name": "toolEfficiency",
      "label": "ƒ toolEfficiency",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:toolLayer",
      "name": "toolLayer",
      "label": "ƒ toolLayer",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-visuals.js:transitionVariant",
      "name": "transitionVariant",
      "label": "ƒ transitionVariant",
      "detail": "função detectada · js/terrain-visuals.js",
      "file": "js/terrain-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:treeDefinition",
      "name": "treeDefinition",
      "label": "ƒ treeDefinition",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:treeNodeAt",
      "name": "treeNodeAt",
      "label": "ƒ treeNodeAt",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:treeStateKey",
      "name": "treeStateKey",
      "label": "ƒ treeStateKey",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:trimExpandedMapBorder",
      "name": "trimExpandedMapBorder",
      "label": "ƒ trimExpandedMapBorder",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:typedImpact",
      "name": "typedImpact",
      "label": "ƒ typedImpact",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:input.js:unbind",
      "name": "unbind",
      "label": "ƒ unbind",
      "detail": "função detectada · js/input.js",
      "file": "js/input.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-v47.js:update",
      "name": "update",
      "label": "ƒ update",
      "detail": "função detectada · js/battle-v47.js",
      "file": "js/battle-v47.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:battle-visuals.js:update",
      "name": "update",
      "label": "ƒ update",
      "detail": "função detectada · js/battle-visuals.js",
      "file": "js/battle-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:ambient-animation.js:updateAndDraw",
      "name": "updateAndDraw",
      "label": "ƒ updateAndDraw",
      "detail": "função detectada · js/ambient-animation.js",
      "file": "js/ambient-animation.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:updateCanvasPresentation",
      "name": "updateCanvasPresentation",
      "label": "ƒ updateCanvasPresentation",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:v00164SpanX",
      "name": "v00164SpanX",
      "label": "ƒ v00164SpanX",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:v00164SpanY",
      "name": "v00164SpanY",
      "label": "ƒ v00164SpanY",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:terrain-visuals.js:variant",
      "name": "variant",
      "label": "ƒ variant",
      "detail": "função detectada · js/terrain-visuals.js",
      "file": "js/terrain-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:viewportBounds",
      "name": "viewportBounds",
      "label": "ƒ viewportBounds",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:sprites.js:weaponAnchor",
      "name": "weaponAnchor",
      "label": "ƒ weaponAnchor",
      "detail": "função detectada · js/sprites.js",
      "file": "js/sprites.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:building-visuals.js:windowFrame",
      "name": "windowFrame",
      "label": "ƒ windowFrame",
      "detail": "função detectada · js/building-visuals.js",
      "file": "js/building-visuals.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:main.js:worldCamera",
      "name": "worldCamera",
      "label": "ƒ worldCamera",
      "detail": "função detectada · js/main.js",
      "file": "js/main.js",
      "source": "runtime",
      "instances": []
    },
    {
      "id": "fn:state-save.js:writeRaw",
      "name": "writeRaw",
      "label": "ƒ writeRaw",
      "detail": "função detectada · js/state-save.js",
      "file": "js/state-save.js",
      "source": "runtime",
      "instances": []
    }
  ]
};
