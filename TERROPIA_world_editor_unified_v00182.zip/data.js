window.WORLD_EDITOR_SEED={
  "schemaVersion": 4,
  "editorVersion": "v00182",
  "sourceWorldMap": "v00163",
  "columns": 20,
  "rows": 21,
  "terrainRows": [
    "~~~~~~~~~~~~~~~NNNN~",
    "~~~~~~~~~~~~~~~~NNNN",
    "~~~~~~~~~~~~~~~NNNNN",
    "~~~~~~~~~~~~BBBBN~N~",
    "~~~~~~~~~~~~~BBBB~~~",
    "~~~~~~~~~~~~BBBBB~~~",
    "~~~~~~~~~SSSSB~B~~~~",
    "~~~~~~~~~~SSSS~~~~~~",
    "~~~~~~~~~SSSSS~~~~~~",
    "MMMM~CCCC~S~S~~~~~~~",
    "~MMMM~CCCC~~~~~~~~~~",
    "MMMMMCCCCC~~~~~~~~~~",
    "~M~M~~C~C~~~~~~~~~~~",
    "~~~~~IIII~~~~~~~~~~~",
    "~~~~~~IIII~~~~~~~~~~",
    "~~~~~IIIII~~~~~~~~~~",
    "~~~~~~I~I~~~~~~~~~~~",
    "AAAAALLLL~~~~~~~~~~~",
    "AAAAA~LLLL~~~~~~~~~~",
    "AAAAALLLLL~~~~~~~~~~",
    "~~~~~~L~L~~~~~~~~~~~"
  ],
  "regions": [
    {
      "code": "A",
      "key": "atenaria",
      "name": "Atenaria",
      "terrain": "fields"
    },
    {
      "code": "L",
      "key": "altaria",
      "name": "Altaria",
      "terrain": "mountains"
    },
    {
      "code": "M",
      "key": "mornaqua",
      "name": "Mornaqua",
      "terrain": "coast"
    },
    {
      "code": "I",
      "key": "invernia",
      "name": "Invérnia",
      "terrain": "snow"
    },
    {
      "code": "C",
      "key": "calindra",
      "name": "Calindra",
      "terrain": "jungle"
    },
    {
      "code": "S",
      "key": "solacia",
      "name": "Solácia",
      "terrain": "desert"
    },
    {
      "code": "B",
      "key": "blaziria",
      "name": "Blazíria",
      "terrain": "volcanic"
    },
    {
      "code": "N",
      "key": "necrovicia",
      "name": "Necrovícia",
      "terrain": "wasteland"
    }
  ],
  "screens": {
    "AT-099": {
      "code": "AT-099",
      "x": 15,
      "y": 0,
      "name": "Entrada Devastada",
      "area": "necrovicia099",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-100": {
      "code": "AT-100",
      "x": 16,
      "y": 0,
      "name": "Trilha das Raízes Mortas",
      "area": "necrovicia100",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-101": {
      "code": "AT-101",
      "x": 17,
      "y": 0,
      "name": "Campo Cinzento",
      "area": "necrovicia101",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-102": {
      "code": "AT-102",
      "x": 18,
      "y": 0,
      "name": "Pedras Negras",
      "area": "necrovicia102",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-103": {
      "code": "AT-103",
      "x": 16,
      "y": 1,
      "name": "Caminho Quebrado",
      "area": "necrovicia103",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-104": {
      "code": "AT-104",
      "x": 17,
      "y": 1,
      "name": "Baixada de Cinzas",
      "area": "necrovicia104",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-105": {
      "code": "AT-105",
      "x": 18,
      "y": 1,
      "name": "Bosque Seco",
      "area": "necrovicia105",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-106": {
      "code": "AT-106",
      "x": 19,
      "y": 1,
      "name": "Passagem dos Espinhos",
      "area": "necrovicia106",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-107": {
      "code": "AT-107",
      "x": 15,
      "y": 2,
      "name": "Planície Morta",
      "area": "necrovicia107",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-108": {
      "code": "AT-108",
      "x": 16,
      "y": 2,
      "name": "Corredor de Pedra Negra",
      "area": "necrovicia108",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-109": {
      "code": "AT-109",
      "x": 17,
      "y": 2,
      "name": "Clareira Pálida",
      "area": "necrovicia109",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-110": {
      "code": "AT-110",
      "x": 18,
      "y": 2,
      "name": "Fenda Silenciosa",
      "area": "necrovicia110",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-111": {
      "code": "AT-111",
      "x": 19,
      "y": 2,
      "name": "Margem Sombria",
      "area": "necrovicia111",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-084": {
      "code": "AT-084",
      "x": 12,
      "y": 3,
      "name": "Base de Basalto",
      "area": "blaziria084",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-085": {
      "code": "AT-085",
      "x": 13,
      "y": 3,
      "name": "Trilha de Cinzas",
      "area": "blaziria085",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-086": {
      "code": "AT-086",
      "x": 14,
      "y": 3,
      "name": "Fratura Escura",
      "area": "blaziria086",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-087": {
      "code": "AT-087",
      "x": 15,
      "y": 3,
      "name": "Encosta Vulcânica",
      "area": "blaziria087",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-112": {
      "code": "AT-112",
      "x": 16,
      "y": 3,
      "name": "Desvio das Raízes",
      "area": "necrovicia112",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-113": {
      "code": "AT-113",
      "x": 18,
      "y": 3,
      "name": "Extremo Nordeste",
      "area": "necrovicia113",
      "type": "overworld",
      "region": "Necrovícia",
      "regionKey": "necrovicia",
      "terrain": "wasteland",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-088": {
      "code": "AT-088",
      "x": 13,
      "y": 4,
      "name": "Campo de Escória",
      "area": "blaziria088",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-089": {
      "code": "AT-089",
      "x": 14,
      "y": 4,
      "name": "Passagem de Obsidiana",
      "area": "blaziria089",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-090": {
      "code": "AT-090",
      "x": 15,
      "y": 4,
      "name": "Vale de Cinzas",
      "area": "blaziria090",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-091": {
      "code": "AT-091",
      "x": 16,
      "y": 4,
      "name": "Dobra de Basalto",
      "area": "blaziria091",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-092": {
      "code": "AT-092",
      "x": 12,
      "y": 5,
      "name": "Terraço Negro",
      "area": "blaziria092",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-093": {
      "code": "AT-093",
      "x": 13,
      "y": 5,
      "name": "Corredor de Rocha",
      "area": "blaziria093",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-094": {
      "code": "AT-094",
      "x": 14,
      "y": 5,
      "name": "Respiradouro Baixo",
      "area": "blaziria094",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-095": {
      "code": "AT-095",
      "x": 15,
      "y": 5,
      "name": "Ladeira de Magma",
      "area": "blaziria095",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-096": {
      "code": "AT-096",
      "x": 16,
      "y": 5,
      "name": "Espigões do Leste",
      "area": "blaziria096",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-069": {
      "code": "AT-069",
      "x": 9,
      "y": 6,
      "name": "Faixa de Areia",
      "area": "solacia069",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-070": {
      "code": "AT-070",
      "x": 10,
      "y": 6,
      "name": "Dunas do Sul",
      "area": "solacia070",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-071": {
      "code": "AT-071",
      "x": 11,
      "y": 6,
      "name": "Planície Seca",
      "area": "solacia071",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-072": {
      "code": "AT-072",
      "x": 12,
      "y": 6,
      "name": "Marco de Arenito",
      "area": "solacia072",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-097": {
      "code": "AT-097",
      "x": 13,
      "y": 6,
      "name": "Desvio das Cinzas",
      "area": "blaziria097",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-098": {
      "code": "AT-098",
      "x": 15,
      "y": 6,
      "name": "Borda Devastada",
      "area": "blaziria098",
      "type": "overworld",
      "region": "Blazíria",
      "regionKey": "blaziria",
      "terrain": "volcanic",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-073": {
      "code": "AT-073",
      "x": 10,
      "y": 7,
      "name": "Trilha do Sol",
      "area": "solacia073",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-074": {
      "code": "AT-074",
      "x": 11,
      "y": 7,
      "name": "Baixio Árido",
      "area": "solacia074",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-075": {
      "code": "AT-075",
      "x": 12,
      "y": 7,
      "name": "Duna Longa",
      "area": "solacia075",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-076": {
      "code": "AT-076",
      "x": 13,
      "y": 7,
      "name": "Passagem do Leste",
      "area": "solacia076",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-077": {
      "code": "AT-077",
      "x": 9,
      "y": 8,
      "name": "Leito Seco",
      "area": "solacia077",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-078": {
      "code": "AT-078",
      "x": 10,
      "y": 8,
      "name": "Campo de Cactos",
      "area": "solacia078",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-079": {
      "code": "AT-079",
      "x": 11,
      "y": 8,
      "name": "Planície de Pedra",
      "area": "solacia079",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-080": {
      "code": "AT-080",
      "x": 12,
      "y": 8,
      "name": "Dunas Altas",
      "area": "solacia080",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-081": {
      "code": "AT-081",
      "x": 13,
      "y": 8,
      "name": "Garganta de Areia",
      "area": "solacia081",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-039": {
      "code": "AT-039",
      "x": 0,
      "y": 9,
      "name": "Costa do Sul",
      "area": "mornaqua039",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-040": {
      "code": "AT-040",
      "x": 1,
      "y": 9,
      "name": "Praia Clara",
      "area": "mornaqua040",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-041": {
      "code": "AT-041",
      "x": 2,
      "y": 9,
      "name": "Dunas Baixas",
      "area": "mornaqua041",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-042": {
      "code": "AT-042",
      "x": 3,
      "y": 9,
      "name": "Ponta das Conchas",
      "area": "mornaqua042",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-054": {
      "code": "AT-054",
      "x": 5,
      "y": 9,
      "name": "Entrada da Selva",
      "area": "calindra054",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-055": {
      "code": "AT-055",
      "x": 6,
      "y": 9,
      "name": "Trilha das Raízes",
      "area": "calindra055",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-056": {
      "code": "AT-056",
      "x": 7,
      "y": 9,
      "name": "Bosque Fechado",
      "area": "calindra056",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-057": {
      "code": "AT-057",
      "x": 8,
      "y": 9,
      "name": "Arco de Cipós",
      "area": "calindra057",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-082": {
      "code": "AT-082",
      "x": 10,
      "y": 9,
      "name": "Desvio das Tâmaras",
      "area": "solacia082",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-083": {
      "code": "AT-083",
      "x": 12,
      "y": 9,
      "name": "Borda do Basalto",
      "area": "solacia083",
      "type": "overworld",
      "region": "Solácia",
      "regionKey": "solacia",
      "terrain": "desert",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-043": {
      "code": "AT-043",
      "x": 1,
      "y": 10,
      "name": "Trilha da Maré",
      "area": "mornaqua043",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-044": {
      "code": "AT-044",
      "x": 2,
      "y": 10,
      "name": "Lagoa Rasa",
      "area": "mornaqua044",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-045": {
      "code": "AT-045",
      "x": 3,
      "y": 10,
      "name": "Faixa de Coqueiros",
      "area": "mornaqua045",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-046": {
      "code": "AT-046",
      "x": 4,
      "y": 10,
      "name": "Enseada do Leste",
      "area": "mornaqua046",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-058": {
      "code": "AT-058",
      "x": 6,
      "y": 10,
      "name": "Clareira Úmida",
      "area": "calindra058",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-059": {
      "code": "AT-059",
      "x": 7,
      "y": 10,
      "name": "Solo de Musgo",
      "area": "calindra059",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-060": {
      "code": "AT-060",
      "x": 8,
      "y": 10,
      "name": "Passagem das Folhas",
      "area": "calindra060",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-061": {
      "code": "AT-061",
      "x": 9,
      "y": 10,
      "name": "Selva Oriental",
      "area": "calindra061",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-047": {
      "code": "AT-047",
      "x": 0,
      "y": 11,
      "name": "Margem de Areia",
      "area": "mornaqua047",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-048": {
      "code": "AT-048",
      "x": 1,
      "y": 11,
      "name": "Passagem das Redes",
      "area": "mornaqua048",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-049": {
      "code": "AT-049",
      "x": 2,
      "y": 11,
      "name": "Baía Serena",
      "area": "mornaqua049",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-050": {
      "code": "AT-050",
      "x": 3,
      "y": 11,
      "name": "Costa dos Corais",
      "area": "mornaqua050",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-051": {
      "code": "AT-051",
      "x": 4,
      "y": 11,
      "name": "Restinga Oriental",
      "area": "mornaqua051",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-062": {
      "code": "AT-062",
      "x": 5,
      "y": 11,
      "name": "Baixada Verde",
      "area": "calindra062",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-063": {
      "code": "AT-063",
      "x": 6,
      "y": 11,
      "name": "Corredor de Raízes",
      "area": "calindra063",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-064": {
      "code": "AT-064",
      "x": 7,
      "y": 11,
      "name": "Clareira do Dossel",
      "area": "calindra064",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-065": {
      "code": "AT-065",
      "x": 8,
      "y": 11,
      "name": "Margem Escura",
      "area": "calindra065",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-066": {
      "code": "AT-066",
      "x": 9,
      "y": 11,
      "name": "Mata de Resina",
      "area": "calindra066",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-052": {
      "code": "AT-052",
      "x": 1,
      "y": 12,
      "name": "Duna Interior",
      "area": "mornaqua052",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-053": {
      "code": "AT-053",
      "x": 3,
      "y": 12,
      "name": "Ponta do Norte",
      "area": "mornaqua053",
      "type": "overworld",
      "region": "Mornaqua",
      "regionKey": "mornaqua",
      "terrain": "coast",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-067": {
      "code": "AT-067",
      "x": 6,
      "y": 12,
      "name": "Desvio das Folhas",
      "area": "calindra067",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-068": {
      "code": "AT-068",
      "x": 8,
      "y": 12,
      "name": "Saída da Selva",
      "area": "calindra068",
      "type": "overworld",
      "region": "Calindra",
      "regionKey": "calindra",
      "terrain": "jungle",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-015": {
      "code": "AT-015",
      "x": 0,
      "y": 17,
      "name": "Estrada dos Campos",
      "area": "atenaria015",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-016": {
      "code": "AT-016",
      "x": 1,
      "y": 17,
      "name": "Clareira do Poente",
      "area": "atenaria016",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-011": {
      "code": "AT-011",
      "x": 2,
      "y": 17,
      "name": "Passagem da Bruxa",
      "area": "witchyard",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Geraldo [gatekeeper]\nBruxa Selene [witch]",
      "resources": "Baú da Bruxa [chest]",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [
          {
            "iid": "AT-011_npcs_geraldo_1",
            "status": "existing",
            "definitionId": "gatekeeper",
            "name": "Geraldo",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 26.56,
              "y": 36.11
            }
          },
          {
            "iid": "AT-011_npcs_bruxa_selene_2",
            "status": "existing",
            "definitionId": "witch",
            "name": "Bruxa Selene",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 26.56,
              "y": 25.0
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-011_resources_simplestaff_1",
            "status": "existing",
            "definitionId": "chest",
            "name": "Baú da Bruxa",
            "quantity": 1,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": true
            },
            "notes": "Spawn legacy chests:witchChest; conteúdo legacy: simpleStaff.",
            "visual": {
              "x": 42.19,
              "y": 13.89
            }
          }
        ],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-012": {
      "code": "AT-012",
      "x": 3,
      "y": 17,
      "name": "Floresta Obscura",
      "area": "darkforest",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "Aranha Sombria [spider1]\nAranha da Névoa [spider2]\nAranha Espinhosa [spider3]\nAranha Venenosa [spider4]",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [
          {
            "iid": "AT-012_enemies_aranha_sombria_1",
            "status": "existing",
            "definitionId": "spider1",
            "name": "Aranha Sombria",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 14.06,
              "y": 25.0
            }
          },
          {
            "iid": "AT-012_enemies_aranha_da_nevoa_2",
            "status": "existing",
            "definitionId": "spider2",
            "name": "Aranha da Névoa",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 23.44,
              "y": 13.89
            }
          },
          {
            "iid": "AT-012_enemies_aranha_espinhosa_3",
            "status": "existing",
            "definitionId": "spider3",
            "name": "Aranha Espinhosa",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 32.81,
              "y": 36.11
            }
          },
          {
            "iid": "AT-012_enemies_aranha_venenosa_4",
            "status": "existing",
            "definitionId": "spider4",
            "name": "Aranha Venenosa",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 42.19,
              "y": 25.0
            }
          }
        ],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-017": {
      "code": "AT-017",
      "x": 4,
      "y": 17,
      "name": "Margem dos Salgueiros",
      "area": "atenaria017",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-024": {
      "code": "AT-024",
      "x": 5,
      "y": 17,
      "name": "Passagem de Granito",
      "area": "altaria024",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-025": {
      "code": "AT-025",
      "x": 6,
      "y": 17,
      "name": "Trilha da Ardósia",
      "area": "altaria025",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-026": {
      "code": "AT-026",
      "x": 7,
      "y": 17,
      "name": "Encosta dos Pinheiros",
      "area": "altaria026",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-027": {
      "code": "AT-027",
      "x": 8,
      "y": 17,
      "name": "Vale Alto",
      "area": "altaria027",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-006": {
      "code": "AT-006",
      "x": 0,
      "y": 18,
      "name": "Vila Carpinelli — Área Oeste",
      "area": "village2",
      "type": "town",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Anciã Mira [elder]\nAlfredo [alfredo]",
      "resources": "Iron [ore:iron] ×3",
      "enemies": "Slime do Musgo [s1]\nSlime Azul [s2]\nSlime Rubro [s3]\nSlime Antigo [s4]",
      "buildings": "",
      "mechanics": "",
      "notes": "Está tela terá saída no leste e no sul. Será fechada no norte e oeste.",
      "entities": {
        "npcs": [
          {
            "iid": "AT-006_npcs_ancia_mira_1",
            "status": "existing",
            "definitionId": "elder",
            "name": "Anciã Mira",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 82.81,
              "y": 52.78
            }
          },
          {
            "iid": "AT-006_npcs_alfredo_2",
            "status": "existing",
            "definitionId": "alfredo",
            "name": "Alfredo",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 42.19,
              "y": 58.33
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-006_resources_iron_1",
            "status": "existing",
            "definitionId": "ore:iron",
            "name": "Iron",
            "quantity": 3,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "",
            "visual": {
              "x": 84,
              "y": 65
            }
          }
        ],
        "enemies": [
          {
            "iid": "AT-006_enemies_slime_do_musgo_1",
            "status": "existing",
            "definitionId": "s1",
            "name": "Slime do Musgo",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 7.81,
              "y": 30.56
            }
          },
          {
            "iid": "AT-006_enemies_slime_azul_2",
            "status": "existing",
            "definitionId": "s2",
            "name": "Slime Azul",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 26.56,
              "y": 30.56
            }
          },
          {
            "iid": "AT-006_enemies_slime_rubro_3",
            "status": "existing",
            "definitionId": "s3",
            "name": "Slime Rubro",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 32.81,
              "y": 30.56
            }
          },
          {
            "iid": "AT-006_enemies_slime_antigo_4",
            "status": "existing",
            "definitionId": "s4",
            "name": "Slime Antigo",
            "quantity": 1,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 42.19,
              "y": 19.44
            }
          }
        ],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-005": {
      "code": "AT-005",
      "x": 1,
      "y": 18,
      "name": "Vila Carpinelli - Entrada",
      "area": "village",
      "type": "town",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Joaquim [farmer]\nHeitor [heitor]",
      "resources": "Iron [ore:iron] ×4\nFramboesa [berry:raspberry] ×3",
      "enemies": "Galinha [chicken3] ×3",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [
          {
            "iid": "AT-005_npcs_joaquim_1",
            "status": "existing",
            "definitionId": "farmer",
            "name": "Joaquim",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 17.19,
              "y": 47.22
            }
          },
          {
            "iid": "AT-005_npcs_heitor_2",
            "status": "existing",
            "definitionId": "heitor",
            "name": "Heitor",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 32.81,
              "y": 30.56
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-005_resources_iron_1",
            "status": "existing",
            "definitionId": "ore:iron",
            "name": "Iron",
            "quantity": 4,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "",
            "visual": {
              "x": 63,
              "y": 42
            }
          },
          {
            "iid": "AT-005_resources_raspberry_5",
            "status": "existing",
            "definitionId": "berry:raspberry",
            "name": "Framboesa",
            "quantity": 3,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "Normalizado a partir dos spawns legacy berries:rasp1/2/3.",
            "visual": {
              "x": 39.06,
              "y": 30.56
            }
          }
        ],
        "enemies": [
          {
            "iid": "AT-005_enemies_galinha_1",
            "status": "existing",
            "definitionId": "chicken3",
            "name": "Galinha",
            "quantity": 3,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 10.94,
              "y": 30.56
            }
          }
        ],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-007": {
      "code": "AT-007",
      "x": 2,
      "y": 18,
      "name": "Entrada da Caverna",
      "area": "entrance",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Clarisse [clarisse]\nJordan [jordan]",
      "resources": "Iron [ore:iron] ×3",
      "enemies": "Rato Gigante [rat2] ×2",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [
          {
            "iid": "AT-007_npcs_clarisse_1",
            "status": "existing",
            "definitionId": "clarisse",
            "name": "Clarisse",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 35.94,
              "y": 30.56
            }
          },
          {
            "iid": "AT-007_npcs_jordan_2",
            "status": "existing",
            "definitionId": "jordan",
            "name": "Jordan",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 20.31,
              "y": 30.56
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-007_resources_iron_1",
            "status": "existing",
            "definitionId": "ore:iron",
            "name": "Iron",
            "quantity": 3,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "",
            "visual": {
              "x": 53,
              "y": 40
            }
          }
        ],
        "enemies": [
          {
            "iid": "AT-007_enemies_rato_gigante_1",
            "status": "existing",
            "definitionId": "rat2",
            "name": "Rato Gigante",
            "quantity": 2,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 17.19,
              "y": 41.67
            }
          }
        ],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-018": {
      "code": "AT-018",
      "x": 3,
      "y": 18,
      "name": "Caminho do Prado",
      "area": "atenaria018",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-019": {
      "code": "AT-019",
      "x": 4,
      "y": 18,
      "name": "Campo do Leste",
      "area": "atenaria019",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-028": {
      "code": "AT-028",
      "x": 6,
      "y": 18,
      "name": "Caminho do Cairn",
      "area": "altaria028",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-029": {
      "code": "AT-029",
      "x": 7,
      "y": 18,
      "name": "Terraço Rochoso",
      "area": "altaria029",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-030": {
      "code": "AT-030",
      "x": 8,
      "y": 18,
      "name": "Ponte de Pedra",
      "area": "altaria030",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-031": {
      "code": "AT-031",
      "x": 9,
      "y": 18,
      "name": "Garganta do Vento",
      "area": "altaria031",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-023": {
      "code": "AT-023",
      "x": 0,
      "y": 19,
      "name": "Vila Carpinelli - Área Sudoeste",
      "area": "atenaria023",
      "type": "town",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "Essa tela terá saída para o norte e leste. Será fechada no oeste e no sul.",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-022": {
      "code": "AT-022",
      "x": 1,
      "y": 19,
      "name": "Vila Carpinelli - Área Sul",
      "area": "atenaria022",
      "type": "town",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Elis [elis]",
      "resources": "Girassol [sunflower] ×3",
      "enemies": "",
      "buildings": "Cabana da Alquimista [elis-cabin]",
      "mechanics": "",
      "notes": "Girassol pode ser colhido. É um item que pode ser usado para criar poção que aumenta o dano causado em 5% por 10 ações de ataque. Os girassóis ficam espalhados pela tela. A Elis explica como funciona o preparo da poção. (você compra um frasco que ela vende, enche de água, usa o girassol no frasco com água e a Poção de Ataque está pronta). 1 de Alquimia é necessário para fazer poção de ataque. Adicionar também uma nova função que é clicar com o botão direito do Mouse sobre um NPC, o que abre menu cascata com as opções \"Falar, Abrir Loja, Cancelar\". A opção \"Abrir Loja\" só vai existir quando o NPC tiver uma loja. O que é o caso da Elis, que vai ter uma loja que vende frasco (por enquanto). O frasco vem vazio, então é preciso usar o frasco na água para encher de água. A Elis fica posicionada dentro da cabana. Então criar o interior da Cabana dela também, com itens de alquimia como decoração. Essa tela terá saída para o norte e para o oeste. Será fechada no leste e no sul.",
      "entities": {
        "npcs": [
          {
            "iid": "AT-022_npcs_elis_1",
            "status": "existing",
            "definitionId": "elis",
            "name": "Elis",
            "quantity": 1,
            "properties": {
              "role": "Alquimista",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": true,
                "quest": false,
                "combat": false
              },
              "shopId": "elis-shop",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 57,
              "y": 61
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-022_resources_girassol_1",
            "status": "existing",
            "definitionId": "sunflower",
            "name": "Girassol",
            "quantity": 3,
            "properties": {
              "distribution": "três pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "",
            "visual": {
              "x": 17.19,
              "y": 30.56
            }
          }
        ],
        "enemies": [],
        "buildings": [
          {
            "iid": "AT-022_buildings_cabana_da_alquimista_1",
            "status": "existing",
            "definitionId": "elis-cabin",
            "name": "Cabana da Alquimista",
            "quantity": 1,
            "properties": {
              "enterable": true,
              "interiorId": "interior_alchemist_hut",
              "collision": true,
              "door": true,
              "function": "Alquimia / Loja da Elis"
            },
            "notes": "",
            "visual": {
              "x": 50,
              "y": 20
            }
          }
        ]
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [
        {
          "iid": "AT-022_interior_alchemist_hut",
          "id": "interior_alchemist_hut",
          "name": "Interior da Cabana da Alquimista",
          "linkedBuildingIid": "AT-022_buildings_cabana_da_alquimista_1",
          "returnToScreen": true,
          "implemented": true,
          "notes": "Interior vinculado à AT-022 com Elis e decoração de alquimia."
        }
      ],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-014": {
      "code": "AT-014",
      "x": 2,
      "y": 19,
      "name": "Floresta dos Cogumelos",
      "area": "mushroomforest",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "Gnomo Júlio [gnome]",
      "resources": "Iron [ore:iron] ×2\nCogumelo [berry:mushroom] ×2",
      "enemies": "Capivara [capybara2] ×2",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [
          {
            "iid": "AT-014_npcs_gnomo_julio_1",
            "status": "existing",
            "definitionId": "gnome",
            "name": "Gnomo Júlio",
            "quantity": 1,
            "properties": {
              "role": "",
              "behavior": "parado",
              "interactions": {
                "talk": true,
                "shop": false,
                "quest": false,
                "combat": false
              },
              "shopId": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 57.81,
              "y": 58.33
            }
          }
        ],
        "resources": [
          {
            "iid": "AT-014_resources_iron_1",
            "status": "existing",
            "definitionId": "ore:iron",
            "name": "Iron",
            "quantity": 2,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "",
            "visual": {
              "x": 23,
              "y": 59
            }
          },
          {
            "iid": "AT-014_resources_mushroom_3",
            "status": "existing",
            "definitionId": "berry:mushroom",
            "name": "Cogumelo",
            "quantity": 2,
            "properties": {
              "distribution": "pontos distintos",
              "respawn": "normal",
              "gathering": "manual",
              "requirement": "nenhum",
              "persistent": false
            },
            "notes": "Normalizado a partir dos spawns legacy berries:mush1/2.",
            "visual": {
              "x": 32.81,
              "y": 36.11
            }
          }
        ],
        "enemies": [
          {
            "iid": "AT-014_enemies_capivara_1",
            "status": "existing",
            "definitionId": "capybara2",
            "name": "Capivara",
            "quantity": 2,
            "properties": {
              "respawn": "normal",
              "aggressive": true,
              "patrol": "",
              "condition": "sempre"
            },
            "notes": "",
            "visual": {
              "x": 76.56,
              "y": 41.67
            }
          }
        ],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-020": {
      "code": "AT-020",
      "x": 3,
      "y": 19,
      "name": "Trilha das Flores",
      "area": "atenaria020",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-021": {
      "code": "AT-021",
      "x": 4,
      "y": 19,
      "name": "Baixio Verde",
      "area": "atenaria021",
      "type": "overworld",
      "region": "Atenaria",
      "regionKey": "atenaria",
      "terrain": "fields",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-032": {
      "code": "AT-032",
      "x": 5,
      "y": 19,
      "name": "Base da Serra",
      "area": "altaria032",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-033": {
      "code": "AT-033",
      "x": 6,
      "y": 19,
      "name": "Rampa de Lajes",
      "area": "altaria033",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-034": {
      "code": "AT-034",
      "x": 7,
      "y": 19,
      "name": "Clareira Alpina",
      "area": "altaria034",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-035": {
      "code": "AT-035",
      "x": 8,
      "y": 19,
      "name": "Costão do Norte",
      "area": "altaria035",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-036": {
      "code": "AT-036",
      "x": 9,
      "y": 19,
      "name": "Varanda de Pedra",
      "area": "altaria036",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-037": {
      "code": "AT-037",
      "x": 6,
      "y": 20,
      "name": "Desvio dos Pinheiros",
      "area": "altaria037",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-038": {
      "code": "AT-038",
      "x": 8,
      "y": 20,
      "name": "Passo Oriental",
      "area": "altaria038",
      "type": "overworld",
      "region": "Altaria",
      "regionKey": "altaria",
      "terrain": "mountains",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-114": {
      "code": "AT-114",
      "x": 5,
      "y": 13,
      "name": "Portal da Neve",
      "area": "invernia114",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-115": {
      "code": "AT-115",
      "x": 6,
      "y": 13,
      "name": "Planície Branca",
      "area": "invernia115",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-116": {
      "code": "AT-116",
      "x": 7,
      "y": 13,
      "name": "Trilha Congelada",
      "area": "invernia116",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-117": {
      "code": "AT-117",
      "x": 8,
      "y": 13,
      "name": "Bosque de Gelo",
      "area": "invernia117",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-118": {
      "code": "AT-118",
      "x": 6,
      "y": 14,
      "name": "Lago Cristalino",
      "area": "invernia118",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-119": {
      "code": "AT-119",
      "x": 7,
      "y": 14,
      "name": "Campo de Geada",
      "area": "invernia119",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-120": {
      "code": "AT-120",
      "x": 8,
      "y": 14,
      "name": "Passagem Nevada",
      "area": "invernia120",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-121": {
      "code": "AT-121",
      "x": 9,
      "y": 14,
      "name": "Pinheiral Gelado",
      "area": "invernia121",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-122": {
      "code": "AT-122",
      "x": 5,
      "y": 15,
      "name": "Vale Azul",
      "area": "invernia122",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-123": {
      "code": "AT-123",
      "x": 6,
      "y": 15,
      "name": "Escarpa de Gelo",
      "area": "invernia123",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-124": {
      "code": "AT-124",
      "x": 7,
      "y": 15,
      "name": "Nevasca Baixa",
      "area": "invernia124",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-125": {
      "code": "AT-125",
      "x": 8,
      "y": 15,
      "name": "Clareira Boreal",
      "area": "invernia125",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-126": {
      "code": "AT-126",
      "x": 9,
      "y": 15,
      "name": "Cristas Nevadas",
      "area": "invernia126",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-127": {
      "code": "AT-127",
      "x": 6,
      "y": 16,
      "name": "Garganta Glacial",
      "area": "invernia127",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    },
    "AT-128": {
      "code": "AT-128",
      "x": 8,
      "y": 16,
      "name": "Fronteira do Gelo",
      "area": "invernia128",
      "type": "overworld",
      "region": "Invérnia",
      "regionKey": "invernia",
      "terrain": "snow",
      "npcs": "",
      "resources": "",
      "enemies": "",
      "buildings": "",
      "mechanics": "",
      "notes": "",
      "entities": {
        "npcs": [],
        "resources": [],
        "enemies": [],
        "buildings": []
      },
      "designControl": {
        "freedom": "structured",
        "restrictions": {
          "camera": false,
          "connections": false,
          "npcs": false,
          "quests": false,
          "difficulty": false,
          "layout": false
        },
        "other": ""
      },
      "interiors": [],
      "blueprint": {
        "background": "auto",
        "notes": ""
      }
    }
  },
  "libraries": {
    "npcs": [
      {
        "id": "elder",
        "name": "Anciã Mira",
        "label": "🧓 Anciã Mira",
        "detail": "elder · área atual: village2"
      },
      {
        "id": "farmer",
        "name": "Joaquim",
        "label": "👨‍🌾 Joaquim",
        "detail": "farmer · área atual: village"
      },
      {
        "id": "shop",
        "name": "Lojista",
        "label": "🧑‍💼 Lojista",
        "detail": "shop · área atual: shopInterior"
      },
      {
        "id": "heitor",
        "name": "Heitor",
        "label": "🧒 Heitor",
        "detail": "heitor · área atual: village"
      },
      {
        "id": "clarisse",
        "name": "Clarisse",
        "label": "👧 Clarisse",
        "detail": "clarisse · área atual: entrance"
      },
      {
        "id": "jordan",
        "name": "Jordan",
        "label": "👴 Jordan",
        "detail": "jordan · área atual: entrance"
      },
      {
        "id": "gatekeeper",
        "name": "Geraldo",
        "label": "🧙‍♂️ Geraldo",
        "detail": "gatekeeper · área atual: witchyard"
      },
      {
        "id": "witch",
        "name": "Bruxa Selene",
        "label": "🧙‍♀️ Bruxa Selene",
        "detail": "witch · área atual: witchyard"
      },
      {
        "id": "alfredo",
        "name": "Alfredo",
        "label": "👨‍🌾 Alfredo",
        "detail": "alfredo · área atual: village2"
      },
      {
        "id": "carlos",
        "name": "Carlos",
        "label": "🧑‍💼 Carlos",
        "detail": "carlos · área atual: bank"
      },
      {
        "id": "cecilia",
        "name": "Cecília",
        "label": "🧑‍💼 Cecília",
        "detail": "cecilia · área atual: bank"
      },
      {
        "id": "clovis",
        "name": "Clóvis",
        "label": "🧑‍💼 Clóvis",
        "detail": "clovis · área atual: bank"
      },
      {
        "id": "gnome",
        "name": "Gnomo Júlio",
        "label": "🧙‍♂️ Gnomo Júlio",
        "detail": "gnome · área atual: mushroomforest"
      },
      {
        "id": "elis",
        "name": "Elis",
        "label": "🧪 Elis",
        "detail": "Alquimista · Cabana da Alquimista · loja de frascos"
      }
    ],
    "resources": [
      {
        "id": "tree:iron",
        "name": "Carvalho",
        "label": "🌳 Carvalho",
        "detail": "Woodcutting · material iron · drop Lenha de Carvalho"
      },
      {
        "id": "tree:mithril",
        "name": "Salgueiro Arcano",
        "label": "🌳 Salgueiro Arcano",
        "detail": "Woodcutting · material mithril · drop Lenha de Salgueiro Arcano"
      },
      {
        "id": "tree:platinum",
        "name": "Coqueiro",
        "label": "🌳 Coqueiro",
        "detail": "Woodcutting · material platinum · drop Lenha de Coqueiro"
      },
      {
        "id": "tree:silver",
        "name": "Pinheiro Gelado",
        "label": "🌳 Pinheiro Gelado",
        "detail": "Woodcutting · material silver · drop Lenha de Pinheiro Gelado"
      },
      {
        "id": "tree:gold",
        "name": "Cedro Dourado",
        "label": "🌳 Cedro Dourado",
        "detail": "Woodcutting · material gold · drop Lenha de Cedro Dourado"
      },
      {
        "id": "tree:ruby",
        "name": "Bordo Rubro",
        "label": "🌳 Bordo Rubro",
        "detail": "Woodcutting · material ruby · drop Lenha de Bordo Rubro"
      },
      {
        "id": "tree:diamond",
        "name": "Árvore de Cristal",
        "label": "🌳 Árvore de Cristal",
        "detail": "Woodcutting · material diamond · drop Lenha de Árvore de Cristal"
      },
      {
        "id": "tree:onyx",
        "name": "Ébano Sombrio",
        "label": "🌳 Ébano Sombrio",
        "detail": "Woodcutting · material onyx · drop Lenha de Ébano Sombrio"
      },
      {
        "id": "ore:iron",
        "name": "Iron",
        "label": "⛏️ Minério: iron",
        "detail": "Mining · tier/material iron"
      },
      {
        "id": "ore:mithril",
        "name": "Mithril",
        "label": "⛏️ Minério: mithril",
        "detail": "Mining · tier/material mithril"
      },
      {
        "id": "ore:platinum",
        "name": "Platinum",
        "label": "⛏️ Minério: platinum",
        "detail": "Mining · tier/material platinum"
      },
      {
        "id": "ore:silver",
        "name": "Silver",
        "label": "⛏️ Minério: silver",
        "detail": "Mining · tier/material silver"
      },
      {
        "id": "ore:gold",
        "name": "Gold",
        "label": "⛏️ Minério: gold",
        "detail": "Mining · tier/material gold"
      },
      {
        "id": "ore:ruby",
        "name": "Ruby",
        "label": "⛏️ Minério: ruby",
        "detail": "Mining · tier/material ruby"
      },
      {
        "id": "ore:diamond",
        "name": "Diamond",
        "label": "⛏️ Minério: diamond",
        "detail": "Mining · tier/material diamond"
      },
      {
        "id": "ore:onyx",
        "name": "Onyx",
        "label": "⛏️ Minério: onyx",
        "detail": "Mining · tier/material onyx"
      },
      {
        "id": "berry:raspberry",
        "name": "Framboesa",
        "label": "🫐 Framboesa",
        "detail": "Coleta em arbusto"
      },
      {
        "id": "berry:blueRaspberry",
        "name": "Framboesa Azul",
        "label": "🔵 Framboesa Azul",
        "detail": "Coleta rara em arbusto"
      },
      {
        "id": "berry:mushroom",
        "name": "Cogumelo",
        "label": "🍄 Cogumelo",
        "detail": "Coleta em floresta"
      },
      {
        "id": "chest",
        "name": "Baú",
        "label": "🧰 Baú / recompensa",
        "detail": "Recurso interagível com loot"
      },
      {
        "id": "fishing-water",
        "name": "Ponto de Pesca",
        "label": "🎣 Ponto de Pesca",
        "detail": "Água pescável / ecossistema local"
      },
      {
        "id": "farm-plot",
        "name": "Plantio",
        "label": "🌱 Canteiro de Plantação",
        "detail": "Plantio, fertilizante e colheita"
      },
      {
        "id": "sunflower",
        "name": "Girassol",
        "label": "🌻 Girassol",
        "detail": "Coletável em AT-022 · reagente da Poção de Ataque"
      }
    ],
    "enemies": [
      {
        "id": "s1",
        "name": "Slime do Musgo",
        "label": "🟢 Slime do Musgo",
        "detail": "s1 · família slime"
      },
      {
        "id": "s2",
        "name": "Slime Azul",
        "label": "🔵 Slime Azul",
        "detail": "s2 · família slime"
      },
      {
        "id": "s3",
        "name": "Slime Rubro",
        "label": "🔴 Slime Rubro",
        "detail": "s3 · família slime"
      },
      {
        "id": "s4",
        "name": "Slime Antigo",
        "label": "🟣 Slime Antigo",
        "detail": "s4 · família slime"
      },
      {
        "id": "chicken3",
        "name": "Galinha",
        "label": "🐔 Galinha",
        "detail": "chicken3"
      },
      {
        "id": "b1",
        "name": "Morcego Sombrio",
        "label": "🦇 Morcego Sombrio",
        "detail": "b1"
      },
      {
        "id": "b2",
        "name": "Morcego da Caverna",
        "label": "🦇 Morcego da Caverna",
        "detail": "b2"
      },
      {
        "id": "b3",
        "name": "Morcego Feroz",
        "label": "🦇 Morcego Feroz",
        "detail": "b3"
      },
      {
        "id": "b4",
        "name": "Morcego Cinzento",
        "label": "🦇 Morcego Cinzento",
        "detail": "b4"
      },
      {
        "id": "caveWolf1",
        "name": "Lobo da Caverna",
        "label": "🐺 Lobo da Caverna",
        "detail": "caveWolf1"
      },
      {
        "id": "caveWolf2",
        "name": "Lobo Cinzento",
        "label": "🐺 Lobo Cinzento",
        "detail": "caveWolf2"
      },
      {
        "id": "wolfGuard",
        "name": "Lobo Guardião",
        "label": "🐺 Lobo Guardião",
        "detail": "wolfGuard"
      },
      {
        "id": "caveWolf3",
        "name": "Lobo Feroz",
        "label": "🐺 Lobo Feroz",
        "detail": "caveWolf3"
      },
      {
        "id": "caveWolf4",
        "name": "Lobo Sombrio",
        "label": "🐺 Lobo Sombrio",
        "detail": "caveWolf4"
      },
      {
        "id": "wolf",
        "name": "Lobo Gigante",
        "label": "🐺 Lobo Gigante",
        "detail": "wolf · chefe"
      },
      {
        "id": "rat2",
        "name": "Rato Gigante",
        "label": "🐀 Rato Gigante",
        "detail": "rat2"
      },
      {
        "id": "capybara2",
        "name": "Capivara",
        "label": "🟤 Capivara",
        "detail": "capybara2"
      },
      {
        "id": "spider1",
        "name": "Aranha Sombria",
        "label": "🕷️ Aranha Sombria",
        "detail": "spider1"
      },
      {
        "id": "spider2",
        "name": "Aranha da Névoa",
        "label": "🕷️ Aranha da Névoa",
        "detail": "spider2"
      },
      {
        "id": "spider3",
        "name": "Aranha Espinhosa",
        "label": "🕷️ Aranha Espinhosa",
        "detail": "spider3"
      },
      {
        "id": "spider4",
        "name": "Aranha Venenosa",
        "label": "🕷️ Aranha Venenosa",
        "detail": "spider4"
      },
      {
        "id": "giantSpider",
        "name": "Aranha Gigante",
        "label": "🕷️ Aranha Gigante",
        "detail": "giantSpider · chefe"
      },
      {
        "id": "dragon",
        "name": "Dragão Ancestral",
        "label": "🐉 Dragão Ancestral",
        "detail": "dragon · chefe"
      },
      {
        "id": "goat",
        "name": "Bode",
        "label": "🐐 Bode",
        "detail": "goat"
      }
    ],
    "buildings": [
      {
        "id": "player-house",
        "name": "Casa do Jogador",
        "label": "🏠 Casa do Jogador",
        "detail": "Interior + porta/conexão"
      },
      {
        "id": "smithy",
        "name": "Ferraria",
        "label": "🔥 Ferraria",
        "detail": "Forja, bigorna e crafting de equipamento"
      },
      {
        "id": "bank",
        "name": "Banco",
        "label": "🏦 Banco",
        "detail": "Armazenamento + NPCs banqueiros"
      },
      {
        "id": "shop",
        "name": "Loja",
        "label": "🏪 Loja",
        "detail": "Compra e venda"
      },
      {
        "id": "cave-entrance",
        "name": "Entrada de Caverna",
        "label": "🪨 Entrada de Caverna",
        "detail": "Porta/transição para dungeon"
      },
      {
        "id": "house",
        "name": "Casa genérica",
        "label": "🏡 Casa / construção",
        "detail": "Construção decorativa ou funcional"
      },
      {
        "id": "bridge",
        "name": "Ponte",
        "label": "🌉 Ponte",
        "detail": "Passagem sobre terreno/água"
      },
      {
        "id": "fence",
        "name": "Cerca",
        "label": "🪵 Cerca",
        "detail": "Barreira/limite de área"
      },
      {
        "id": "dock",
        "name": "Cais",
        "label": "⚓ Cais",
        "detail": "Construção costeira / pesca"
      },
      {
        "id": "elis-cabin",
        "name": "Cabana da Alquimista",
        "label": "🧪 Cabana da Alquimista",
        "detail": "Interior vinculado à AT-022 · Elis + decoração de alquimia"
      }
    ],
    "mechanics": [
      {
        "id": "screen-transition",
        "name": "Transição por borda",
        "label": "⚙️ Transição por borda",
        "detail": "Conecta telas por N/S/L/O; adjacência do Editor gera a proposta de conexão.",
        "file": "js/main.js · handleEdgeTransition"
      },
      {
        "id": "npc-dialogue",
        "name": "NPC + diálogo",
        "label": "⚙️ NPC + diálogo",
        "detail": "NPC interagível com fala, estado e possíveis quests.",
        "file": "data/content.js · js/main.js"
      },
      {
        "id": "quest-marker",
        "name": "Marcador de Quest",
        "label": "⚙️ Marcador de Quest",
        "detail": "Estado visual verde/amarelo/vermelho com exclamação branca.",
        "file": "js/quest.js · js/main.js"
      },
      {
        "id": "cutscene",
        "name": "Cutscene scriptada",
        "label": "⚙️ Cutscene scriptada",
        "detail": "Sequência de diálogo/ação; câmera só faz zoom/follow quando explicitamente solicitado.",
        "file": "js/main.js · camera polish"
      },
      {
        "id": "combat",
        "name": "Combate",
        "label": "⚙️ Combate",
        "detail": "Inimigos, drops, XP, resistências, fraquezas e bosses.",
        "file": "js/battle.js · data/content.js"
      },
      {
        "id": "mining",
        "name": "Mineração",
        "label": "⚙️ Mineração",
        "detail": "Nós de minério por material/tier, ferramenta, XP e respawn.",
        "file": "js/gathering.js · data/resources.js"
      },
      {
        "id": "woodcutting",
        "name": "Corte de árvores",
        "label": "⚙️ Corte de árvores",
        "detail": "Árvores coletáveis, ferramenta, XP, stump e respawn.",
        "file": "js/gathering.js · data/resources.js"
      },
      {
        "id": "fishing",
        "name": "Pesca",
        "label": "⚙️ Pesca",
        "detail": "Pontos de água, iscas, peixes, clima e raridade.",
        "file": "js/main.js · data/fish.js"
      },
      {
        "id": "farming",
        "name": "Plantação",
        "label": "⚙️ Plantação",
        "detail": "Canteiro, sementes, fertilizantes, crescimento e colheita.",
        "file": "js/main.js"
      },
      {
        "id": "crafting",
        "name": "Crafting",
        "label": "⚙️ Crafting",
        "detail": "Receitas, produção, filas/tempo e skill checks.",
        "file": "js/crafting.js · data/recipes.js"
      },
      {
        "id": "smithing",
        "name": "Ferraria",
        "label": "⚙️ Ferraria",
        "detail": "Forja/bigorna, barras e criação de equipamento.",
        "file": "js/main.js · data/equipment.js"
      },
      {
        "id": "cooking",
        "name": "Culinária",
        "label": "⚙️ Culinária",
        "detail": "Fogão/fogueira, comida, cura e buffs.",
        "file": "js/main.js"
      },
      {
        "id": "bank",
        "name": "Banco",
        "label": "⚙️ Banco",
        "detail": "Depósito, retirada e capacidade de armazenamento.",
        "file": "js/main.js"
      },
      {
        "id": "shop",
        "name": "Loja",
        "label": "⚙️ Loja",
        "detail": "Compra/venda e economia.",
        "file": "data/economy.js · js/main.js"
      },
      {
        "id": "chest",
        "name": "Baú / recompensa",
        "label": "⚙️ Baú / recompensa",
        "detail": "Interação de loot, requisitos e proteção por inimigo.",
        "file": "data/content.js"
      },
      {
        "id": "equipment",
        "name": "Equipamentos",
        "label": "⚙️ Equipamentos",
        "detail": "Slots, stats, equip/unequip e sprites de itens.",
        "file": "data/equipment.js · js/main.js"
      },
      {
        "id": "skill-check",
        "name": "Skill Check",
        "label": "⚙️ Skill Check",
        "detail": "Requisitos de skill para rotas, quests e conteúdo.",
        "file": "data/quest-skill-checks.js"
      },
      {
        "id": "world-project",
        "name": "Projeto de Mundo",
        "label": "⚙️ Projeto de Mundo",
        "detail": "Projetos persistentes que liberam conveniências/efeitos.",
        "file": "data/world-projects.js"
      },
      {
        "id": "random-encounter",
        "name": "Encontro Aleatório",
        "label": "⚙️ Encontro Aleatório",
        "detail": "Combate/evento acionado fora de spawn fixo.",
        "file": "js/main.js"
      },
      {
        "id": "weather",
        "name": "Clima",
        "label": "⚙️ Clima",
        "detail": "Estados climáticos usados por pesca/ambiente.",
        "file": "js/main.js"
      },
      {
        "id": "door-interior",
        "name": "Porta / Interior",
        "label": "⚙️ Porta / Interior",
        "detail": "Conexão explícita para tela interior sem tile próprio no overworld.",
        "file": "data/map-codes.js · data/content.js"
      },
      {
        "id": "npc-context-menu",
        "name": "Menu contextual de NPC",
        "label": "⚙️ Menu contextual de NPC",
        "detail": "Botão direito: Falar / Abrir Loja (quando houver) / Cancelar.",
        "file": "js/main.js"
      },
      {
        "id": "attack-potion",
        "name": "Poção de Ataque",
        "label": "⚙️ Poção de Ataque",
        "detail": "Frasco Vazio → água → Frasco com Água + Girassol; Alquimia 1; +5% dano por 10 ataques.",
        "file": "js/main.js · js/inventory.js"
      }
    ]
  },
  "connectionMeta": {},
  "runtimeLibraryGeneratedAt": "2026-08-17T00:14:19.932Z",
  "templates": []
};
