# Editor de Mundo — Terrópia v00182

Abra `../world-editor.html` ou `index.html`. A entrada detecta automaticamente iPhone/mobile ou desktop. Ambas usam a mesma base e o mesmo formato de projeto; consulte `../WORLD_EDITOR_UNIFIED_v00182.md`.

## Etapa 3 — ferramenta completa de RPG

A Etapa 3 preserva as Etapas 1 e 2 e acrescenta uma camada de lógica de RPG diretamente ao protocolo Editor → implementação.

### 1. Event Builder + Event Pages/Estados
Cada tela pode possuir eventos estruturados no formato **QUANDO → SE → ENTÃO**.

- Triggers: entrada na tela, interação, proximidade, atualização de quest, fim de combate, timer ou custom.
- Cada evento possui múltiplas páginas/estados com prioridade e camada.
- Condições: Flag, Quest, Skill, Item, Camada ou Custom.
- Ações: Diálogo, Set Flag, Quest Start/Update/Complete, Give/Take Item, Camera Focus/Restore, Spawn/Remove Entity, Layer On/Off, Teleport ou Custom.
- O validador avisa, por exemplo, quando existe `cameraFocus` sem `cameraRestore` posterior.

### 2. Quest Graph
O painel **RPG → Quest Graph** importa automaticamente quests detectadas no runtime e permite criar novas.

Cada quest possui ID permanente, tipo, giver, telas envolvidas, pré-requisitos, condição de conclusão, recompensas e notas. Dependências entre quests são desenhadas como um grafo e ciclos são detectados pela validação.

### 3. Camadas de mundo
O Editor possui uma camada `base` obrigatória e permite criar camadas condicionais como `pós-quest`, `cidade reconstruída`, `invasão`, etc.

Telas, entidades individuais e Event Pages podem referenciar camadas. Assim NPCs, recursos, inimigos e construções podem existir apenas em um estado específico do mundo. Camadas carregam condição, estado padrão e descrição.

### 4. Progression View + progression locks
As conexões mantêm o requisito legível e agora também possuem um lock estruturado:

- Quest
- Skill
- Flag
- Item
- Custom

A Progression View cruza esses locks com pré-requisitos de quests e marcos detectados no runtime.

### 5. Validação de progressão
Além da validação estrutural anterior, o Editor verifica:

- ciclos no Quest Graph;
- quests/telas/layers inexistentes;
- locks sem ID;
- quest locks apontando para quests inexistentes;
- skills não detectadas na progressão;
- flags exigidas sem produtor conhecido;
- eventos sem páginas;
- referências de camadas quebradas;
- foco de câmera sem restauração posterior.

### 6. Critérios de aceite automáticos
O Editor deriva critérios de aceite a partir do Change Set.

Eles aparecem em **RPG → Critérios**, entram no `WORLD_EDITOR_CHANGES.json` e podem ser exportados em `WORLD_EDITOR_ACCEPTANCE.json`.

### 7. Gerador de testes
**RPG → Testes** gera `WORLD_EDITOR_GENERATED_TESTS.js`.

O teste é pensado para ser colocado em `tests/` após a implementação e verifica critérios automatizáveis contra `data/`, `js/` e `index.html`.

### 8. Divergência Editor ↔ Runtime
**RPG → Editor ↔ Runtime** audita:

- posições das telas do mapa;
- definições marcadas como EXISTENTE;
- quests existentes;
- hash do manifesto de runtime;
- mudanças do Editor ainda não reconciliadas.

Mudanças autorais pendentes aparecem como **informação**, não como falso erro de runtime. O cabeçalho mantém um indicador **Runtime ✓ / alertas** que recalcula a auditoria automaticamente enquanto o projeto é editado.

## Catálogo do runtime

`tools/generate-world-editor-runtime-library.js` agora extrai:

- 120 telas do world map;
- quests principais/sidequests/profissionais;
- marcos de progressão profissional/endgame;
- NPCs, recursos, inimigos e construções;
- mecânicas;
- registries e funções técnicas.

Regere sempre que o runtime mudar:

```bash
node tools/generate-world-editor-runtime-library.js
```

## Recursos herdados

- Blueprint 16:9, drag-and-drop e entradas/saídas visuais.
- Templates, multi-seleção, overlays e busca “Onde isto é usado?”.
- Cards EXISTENTE/NOVO, interiores, metadata de conexão e Controle de Design.
- Diff, validação, Undo/Redo, Snapshot, Changes e Prompt.

## Exportação recomendada

1. `WORLD_EDITOR_CHANGES.json` — diferenças autorais, critérios e validação.
2. `WORLD_EDITOR_SNAPSHOT.json` — estado completo para reconciliação.
3. `WORLD_EDITOR_PROMPT.md` — resumo humano.
4. `WORLD_EDITOR_ACCEPTANCE.json` — opcional, critérios isolados.
5. `WORLD_EDITOR_GENERATED_TESTS.js` — opcional, teste gerado.

O navegador não reescreve silenciosamente o ZIP local. Inclua os exports no ZIP antes de reenviar o projeto.
